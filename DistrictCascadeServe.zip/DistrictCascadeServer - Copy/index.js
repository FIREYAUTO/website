//{{ Internal Functions }}\\

const { json } = require("stream/consumers");

function multi_require(...Modules){
	return Modules.map(x=>require(x));
}

//{{ Required Modules }}\\

const [http,fs,config,https]=multi_require("http","fs","./config.json","https");

//{{ HTTPs Library }}\\

const HTTPs = {
	Request:async function(Host,Path,Method){
		let Response = await new Promise(res=>{
			let req = https.request({
				hostname:Host,
				path:Path,
				method:Method,
			},r=>{r.on("data",d=>res(d))});
			req.end()
		}).then(a=>a);
		return Response;
	},
	Get:async function(Host,Path){
		return await HTTPs.Request(Host,Path,"GET");
	},
}

//{{ Constants }}\\

const endpointDirectory = `${__dirname}${config.endpointDirectory}`,
	endpointCache = {},
	debug = true;

const globals = {
	verifyCache:{},
	alreadyInVerificationFile:(DId,RId)=>{
		let fileContent = String(fs.readFileSync(config.verificationFile));
		if(DId!=undefined){
			let dMatch = fileContent.match(new RegExp(`\\,${DId}\\:`));
			if(dMatch!=null)return {In:true,Status:0};
		}
		let rMatch = fileContent.match(new RegExp(`\\:${RId}\\,`));
		if(rMatch!=null)return {In:true,Status:1};
		return {In:false};
	},
	appendToVerificationFile:(DId,RId)=>{
		fs.appendFileSync(config.verificationFile,`,${DId}:${RId}`);
	},
	https:HTTPs,
	errorCodes:{
		error:0,
		custom:1,
	},
	dummyReturnData:(success=false,response="Unknown Response",errorCode)=>JSON.stringify({Success:success,Response:response,Status:errorCode||0}),
	closeRequest:(res,success=false,response="Unknown Response",errorCode)=>res.end(JSON.stringify({Success:success,Response:response,Status:errorCode||0})),
	bindCloseRequest:(res)=>{return function(...a){return globals.closeRequest(res,...a)}},
	hasOwn:(o,p)=>Object.prototype.hasOwnProperty.call(o,p),
	proxyReq:()=>{
		return {
			end(s){
				return s;
			}
		}
	}
};

//{{ Server }}\\

function readFile(directory,defaultDirectory=endpointDirectory){
	directory=defaultDirectory+directory;
	if(!fs.existsSync(directory))return undefined;
	return fs.readFileSync(directory);
}

function callEndpointModule(module,req,res){
	try{
		let data="";
		req.on("data",chunk=>data+=chunk);
		req.on("end",()=>{
			module.run(req,res,data);
		})
	}catch(e){
		if(debug)console.log(e);
		return closeRequest(res,false,e.message,globals.errorCodes.error);
	}
}

function executeEndpoint(path,req,res){
	if(endpointCache[path])return callEndpointModule(endpointCache[path],req,res);
	let module = require(endpointDirectory+path);
	endpointCache[path]=module;
	module.globals = globals;
	return callEndpointModule(module,req,res);
}

function readEndpoint(url,req,res){
	let file = readFile(url);
	if(file===undefined)return res.end("");
	if(req.method.toLowerCase()!="post")return res.end(`Cannot /${req.method.toUpperCase()}`)
	return executeEndpoint(url,req,res);
}

const server = http.createServer((req,res)=>{
	let url=req.url;
	if(url==="/")return res.end("");
	let file = readFile(url);
	if(file===undefined)return res.end("");
	return readEndpoint(url,req,res);
});

server.listen(config.port,config.ip);
console.log(`Server Started at ${config.ip}:${config.port}`);

//{{ Discord Bot }}\\

const discord = require("discord.js"),
	client = new discord.Client({intents:[discord.GatewayIntentBits.Guilds]});
globals.discord = discord;
globals.client = client;
globals.config = config;
globals._callEndpoint = async function(module,data){
	let res=globals.proxyReq(),req=globals.proxyReq();
	try{
		return await module.run(req,res,data);
	}catch(e){
		if(debug)console.log(e);
		return closeRequest(res,false,e.message,globals.errorCodes.error);
	}
}
globals.callEndpoint = async function(path,data){
	data=JSON.stringify(data);
	path=`/${path}.js`;
	if(endpointCache[path])return await globals._callEndpoint(endpointCache[path],data);
	let module = require(endpointDirectory+path);
	endpointCache[path]=module;
	module.globals = globals;
	return await globals._callEndpoint(module,data);
}

//{{ Command Setup }}\\

const commandArray = [];
client.commands = new discord.Collection();
let commandFiles = fs.readdirSync(__dirname+config.commandsDirectory).filter(file=>file.endsWith(".js"));

for(let file of commandFiles){
	let commandModule = require("."+config.commandsDirectory+"/"+file);
	commandModule.globals=globals;
	let commandData = commandModule.generate();
	let slashCommand = new discord.SlashCommandBuilder()
	slashCommand.setName(commandData.name)
	slashCommand.setDescription(commandData.description)
	if(commandData.onCreate){
		commandData.onCreate(slashCommand);
	}
	let command = {
		data:slashCommand,
		execute:commandData.execute,
		channelIdLock:commandData.channelIdLock,
	}
	commandArray.push(command.data.toJSON());
	client.commands.set(commandData.name,command);
}

//{{ Event Listeners }}\\

client.on(discord.Events.InteractionCreate,async interaction=>{
	if(!interaction.isChatInputCommand())return;
	let command = interaction.client.commands.get(interaction.commandName);
	if(!command)return;
	if(command.channelIdLock)
		if(interaction.channelId!=command.channelIdLock)
			return await interaction.reply({content:`You must be in <#${command.channelIdLock}> to use this command!`,ephemeral:true});
	try {
		let result = await command.execute(interaction);
		if(typeof result==="string")
			result=JSON.parse(result);
		if(!result.Success)
			return await interaction.reply({content:result.Status===globals.errorCodes.error?"An error occurred while executing this command!":result.Response,ephemeral:true});
		return await interaction.reply({content:result.Response});
	}catch(e){
		return await interaction.reply({content:"An error occurred while executing this command!",ephemeral:true})
	}
})

//{{ Register Commands }}\\

const rest = new discord.REST({version:"10"}).setToken(config.botToken);

(async()=>{
	try{
		await rest.put(discord.Routes.applicationGuildCommands(config.botId,config.guildId),{body:commandArray});
	}catch(e){
		console.error(e);
	}
})()

//{{ Client Login }}\\

client.login(config.botToken);