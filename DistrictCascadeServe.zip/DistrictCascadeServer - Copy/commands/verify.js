exports.generate = ()=>{
	const globals=this.globals,
		discord=globals.discord,
		dummyReturnData=globals.dummyReturnData;
	return {
		name:"verify",
		description:"Starts the verification process",
		channelIdLock:"1076235192156553216",
		onCreate:function(slashCommand){
			slashCommand.addStringOption(option=>{
				return option.setName("roblox_username").setDescription("Your Roblox Username").setRequired(true).setAutocomplete(false).setMaxLength(20);
			})
		},
		execute:async function(interaction){
			let username = interaction.options.getString("roblox_username");
			return await globals.callEndpoint("append-verification",{
				RobloxUsername:username,
				DiscordUserId:String(interaction.user.id)
			})
		},
	}
}