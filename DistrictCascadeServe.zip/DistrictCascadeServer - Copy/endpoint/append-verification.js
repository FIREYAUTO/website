exports.run=async(req,res,data)=>{
	const globals = this.globals,
		closeRequest = globals.bindCloseRequest(res),
		verifyCache = globals.verifyCache;
	data=JSON.parse(data);

	//{{ Roblox API Call }}\\

	let RobloxResponse = await globals.https.Get("api.roblox.com","/users/get-by-username?username="+data.RobloxUsername);
	RobloxResponse = JSON.parse(RobloxResponse);
	if(RobloxResponse.errorMessage)
		return closeRequest(false,RobloxResponse.errorMessage,globals.errorCodes.custom);

	//{{ UserId Setup }}\\
	const RobloxUserId = RobloxResponse.Id,
		DiscordUserId = data.DiscordUserId;
	RobloxResponse=undefined;

	//{{ Verification Checks }}\\

	if(globals.hasOwn(verifyCache,RobloxUserId))
		return closeRequest(false,"This user is already in the verification process, please try again later!",globals.errorCodes.custom);
	for(let k in verifyCache)
		if(verifyCache[k][0]===DiscordUserId)
			return closeRequest(false,"You are already verifying a roblox account!",globals.errorCodes.custom);

	//{{ Verification File Checks }}\\

	let Result = globals.alreadyInVerificationFile(DiscordUserId,RobloxUserId);

	if(Result.In)
		return closeRequest(false,Result.Status===0?"You already have a verified account! If you want to remove this verification, please contact the owner":"This roblox user is already verified!",globals.errorCodes.custom);
	
	//{{ Start Verification Process }}\\
	
	let Timeout = setTimeout(()=>{
		delete globals.verifyCache[RobloxUserId]
	},900000)
	verifyCache[RobloxUserId] = [DiscordUserId,Timeout];
	
	return closeRequest(true,"You have began the verification process! Please join the game, and type \`.verify\` to complete the process, and to link your accounts!\n**You have 15 minutes to do so, until you have to start the process again**",globals.errorCodes.custom);
}