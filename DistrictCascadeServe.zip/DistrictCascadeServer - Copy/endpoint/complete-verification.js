exports.run=async(req,res,data)=>{
	const globals = this.globals,
		closeRequest = globals.bindCloseRequest(res),
		verifyCache = globals.verifyCache;
	data=JSON.parse(data);

	//{{ UserId Setup }}\\

	const RobloxUserId = data.RobloxUserId,
		RobloxUsername = data.RobloxUsername;

	//{{ Verification Checks }}\\

	if(!globals.hasOwn(verifyCache,RobloxUserId))
		return closeRequest(false,"You must start the verification process on the discord!",globals.errorCodes.custom);

	//{{ Verification File Checks }}\\

	let Result = globals.alreadyInVerificationFile(undefined,RobloxUserId);

	if(Result.In)
		return closeRequest(false,"This roblox user is already verified!",globals.errorCodes.custom);

	//{{ Complete Verification Process }}\\

	let Item = verifyCache[RobloxUserId];
	clearTimeout(Item[1]);
	delete verifyCache[RobloxUserId];
	
	globals.appendToVerificationFile(Item[0],RobloxUserId);

	try{
		const discord = globals.discord,client = globals.client;
		let guild = client.guilds.cache.get(globals.config.guildId);
		if(guild){
			let members = guild.members;
			members.fetch({user:Item[0],cache:false}).then(member=>{
				member.createDM().then(channel=>{
					channel.send(`You have been successfully verified as \`${RobloxUsername}\` on Roblox! If this was not you, please contact the owner`)
				})
			})
		}
	}catch(e){
		console.log(e);
	}
	
	return closeRequest(true,"You have been successfully verified!",globals.errorCodes.custom);
}