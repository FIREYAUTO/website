//{{ Variables }}\\

const _PATH = "C:/Users/mrfir/OneDrive/Desktop/Coding/JS/JBot/"
const _TOKEN = "OTcyMjYzNTUxNjM5MDkzMjU4.GS526A.XgVT8o7wUYi5jLQgDWKPcnrph8FKFzE7yrMiQg";
const FD = require(_PATH+"fd.js");
const JLANG = require(_PATH+"jlang.js");
const FILE_MANAGER = require(_PATH+"filemanager.js")
const Client = FD.Client;
const RunList = [];
const Blacklist = [];//["339519276941836300"];

FILE_MANAGER.SetDefaultPath(_PATH);

//{{ Backend }}\\

class ProxyError extends Error{
	constructor(Message){
		super(Message).name="[J Error]";
	}
}

const Backend = {
	Embed:function(Title,Description,Color,Fields){
		const NewEmbed = new FD.MessageEmbed();
		  NewEmbed.setColor(Color);
		  NewEmbed.setTitle(Title);
		  NewEmbed.setDescription(Description);
		  for (let Field in Fields){
			  let Ind = Fields[Field];
			  NewEmbed.addField(Ind.name,Ind.value,Ind.inline);
		  }
		  NewEmbed.setTimestamp();
		  return NewEmbed;
	  },
};

//{{ Command System }}\\

const CommandSystem = {
	List:[],
	Add:function(Options){
		this.List.push(Options);
	},
	Check:async function(Message){
		if(Blacklist.includes(Message.Author.ID)){
			let Embed = Backend.Embed("J Error",`You are blacklisted!`,0x1aff4d);
			Message.Channel.Send(Embed);
			return
		}
		if(!Message.Guild||Message.Author.Bot)return;
		let Content = String(Message.Content).substring(0,1400);
		if(!Content.startsWith("J "))return;
		/*
		let Id = Message.Author.Id;
		let Item = RunList[Id];
		let Time = Date.now()/1000;
		if(Item===undefined){
			RunList[Id]=0;
			Item=0;
		}
		if(Time-Item<=2)return Message.Reply("Slow the fuck down!!!!!!!!");
		RunList[Id]=Time;
		*/
		Content=Content.substr(2,Content.length);
		let Result = await JLANG.Run(Message,Content);
		if(!Result.Success){
			let M = `${Result.Error.name}: ${Result.Error.message}`;
			if (Result.Error.name !="[J Error]"){
				M=Result.Error.stack;
			}
			let Embed = Backend.Embed("J Error",`\`${Content}\` errored`,0xff1c4a,[
				{
					name:"Error",
					value:`\`\`\`\n${M}\n\`\`\``
				}
			]);
			Message.Channel.Send(Embed);
		}else{
			let Embed = Backend.Embed("J Success",`\`${Content}\` ran successfully!`,0x1aff4d,[
				{
					name:"Results",
					value:`\`\`\`\n${Result.Results.join("\n")}\n\`\`\``,
				}
			]);
			Message.Channel.Send(Embed);
		}
	},
	RunCommand:async function(Stack,State,Message,Name,Parameters){
		Name=Name.toLowerCase();
		for(let Command of this.List){
			if(Command.Names.includes(Name)){
				if(Command.RequiresOwner===true&&!Stack.IsOwner)throw new ProxyError(`You cannot run the command "${Name}"!`);
				return await Command.Call(Stack,State,Message,...Parameters);
			}
		}
	},
}

//{{ Commands }}\\

CommandSystem.Add({
	Names:["say"],
	Description:"Says the given text",
	Parameters:["Text:String"],
	Call:function(Stack,State,Message,Text){
		Stack.Result(Text);
	}
});

CommandSystem.Add({
	Names:["rnd","random"],
	Description:"Says a random number from Min to Max",
	Parameters:["Min:Integer","Max:Integer"],
	Call:function(Stack,State,Message,Min,Max){
		let Number = Math.floor(Math.random()*(Max-Min+1)+Min);
		return Number;
	}
});

CommandSystem.Add({
	Names:["help"],
	Description:"Help",
	Parameters:[],
	Call:function(Stack,State,Message){
		let Result = [
			"--How to use this bot--",
			"	* This bot uses a semi-programming language like command system. You can create variables, do if statements, iteration loops, repeat loops, arrays, objects, get members/channels, and run commands. You can also call functions in the built in library",
			"	* How to run commands:",
			"		J cmd <Command Name> <Parameter>, ... <Parameters>",
			"	* This command system is a sub-set of Epoxy with some internal changes",
		];
		Stack.Result(...Result);
	}
});

CommandSystem.Add({
	Names:["setallow"],
	RequiresOwner:true,
	Description:"Changes the IsAllowed state in the IStack",
	Parameters:["Enabled:Boolean"],
	Call:function(Stack,State,Message,Enabled){
		Enabled=!!Enabled;
		Stack.IsAllowed=Enabled
		Stack.Result(`Allowed is now ${Enabled}`)
	},
})

CommandSystem.Add({
	Names:["cmds"],
	Description:"List of commands",
	Parameters:[],
	Call:function(Stack,State,Message){
		let Result = [];
		for(let Command of CommandSystem.List){
			let Names = Command.Names.join(",")
			if(Command.Names.length>1){
				Names=`<${Names}>`;
			}
			let Parameters = Command.Parameters.map(x=>`[${x}]`).join(", ");
			Result.push(`${Names} ${Parameters} --${Command.Description}`);
		}
		Stack.Result(...Result);
	}
});

CommandSystem.Add({
	Names:["laugh_at"],
	Description:"Laughs at the given user",
	Parameters:["User:Member"],
	Call:function(Stack,State,Message,User){
		if(!User)return "no user, sorry";
		Message.Channel.Send(`${User.Real.toString()} XDDDDD NOB UR SO BAD!!!!!!! Just get J`);
	}
});

CommandSystem.Add({
	Names:["readfile"],
	RequiresOwner:true,
	Description:"Reads the given file directory",
	Parameters:["Directory:String"],
	Call:function(Stack,State,Message,Directory){
		return FILE_MANAGER.GetFile(Directory);
	}
});

CommandSystem.Add({
	Names:["autpsc"],
	Description:"Prints X amount of AUT private server codes",
	Parameters:["X:Integer"],
	Call:function(Stack,State,Message,X){
		if(X>100)
			return "Stop spamming codes.";
		let Random = function(s){
			return s[Math.floor(Math.random()*(s.length-1))];
		}
		
		function AUTPrivateServerCodeGeneratorFunction(){
			const Chars = "QWERTYUIOPASDFGHJKLZXCVBNM".split("");
			let Str = "";
			for(let i=1;i<=5;i++)
				Str+=Random(Chars);
			return Str;
		}
		
		let Codes = [];
		
		for(let i=1;i<=X;i++)
			Codes.push(AUTPrivateServerCodeGeneratorFunction());
			
		return Codes.join(" ");
	}
})

//{{ Client Setup }}\\

JLANG.AddHooks({Client,FD,_PATH,_TOKEN,CommandSystem,FILE_MANAGER});

Client.Login(_TOKEN);

Client.MessageSent(Message=>{
	CommandSystem.Check(Message);
});

Client.Ready(async()=>{
	console.log(`${Client.User.Name} is online!`);
	Client.User.SetPresence({
		status:"online",
		activity:{
			name:"you",
			type:"WATCHING",
		},
	});
});