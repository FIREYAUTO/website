// -- {{ -=~=- }} -- > Variables < -- {{ -=~=- }} -- \\

const Discord = require("discord.js");
const DiscordClient = new Discord.Client();

const Cache = {
  Inner:{
    Guild:[],
    Channel:[],
    User:[],
    Role:[],
  },
  Exists:function(Type,ID){
    let Result = this.Inner[Type];
    if (!Result){return}
    let Found;
    for (let Value of Result){
      if (Value.ID == ID){
        Found = Value;
        break;
      }
    }
    return Found;
  },
  New:function(Type,P){
    let Result = this.Inner[Type];
    if (!Result){return}
    Result.push(P);
  }
};

// -- {{ -=~=- }} -- > Classes < -- {{ -=~=- }} -- \\

var CacheClient;

const FD = Object.freeze({
  NewProxy:function(Real){
    let PCache = {};
    let P = new Proxy(Real,{
      get:function(self,Name){
        //if (Name == "Real"){return}
        if (PCache[Name]){
          return PCache[Name];
        }
        let Prop = self[Name];
        if (typeof Prop == "function"){
          Prop = Prop.bind(self);
          PCache[Name] = Prop;
        }
        return Prop;
      },
      set:function(self,n,v){
        self[n] = v;
      }
    });
    return P;
  },
  Types:{
    Client:function(Real){
      if (CacheClient){return CacheClient}
      let P = FD.NewProxy({
        User:undefined,
        Real:Real,
        MessageSent:function(Callback){
          this.Real.on("message",Message=>{
            return Callback(FD.new("Message",Message));
          });
        },
        MessageDeleted:function(Callback){
          this.Real.on("messageDelete",Message=>{
            return Callback(FD.new("Message",Message));
          });
        },
        MessageEdited:function(Callback){
          this.Real.on("messageUpdate",(Message,m)=>{
            return Callback(FD.new("Message",Message),FD.new("Message",m));
          });
        },
        Ready:function(Callback){
          this.Real.on("ready",()=>{
            return Callback();
          });
        },
        Login:async function(Token){
          await this.Real.login(Token);
          this.User = FD.new("User",this.Real.user);
        },
        Guilds:[],
        GetGuild:function(ID){
          for (let Guild of this.Guilds){
            if (Guild.ID == ID){
              return Guild;
            }
          }
          let Guild = this.Real.guilds.cache.get(ID);
          if (!Guild){return}
          Guild = FD.new("Guild",Guild);
          this.Guilds.push(Guild);
          return Guild;
        },
        GetGuilds:function(){
          let _ = this;
          this.Real.guilds.cache.each(x=>{
            _.GetGuild(x.id);
          });
          return _.Guilds;
        }
      });
      CacheClient = P;
      return P;
    },
    Guild:function(Real){
      if (!Real){return}
      let Found = Cache.Exists("Guild",Real.id);
      if (Found){return Found}
      let P = FD.NewProxy({
        Real:Real,
        ID:Real.id,
        Name:Real.name,
        Users:[],
        Roles:[],
        Channels:[],
        GetUser:function(ID){
          for (let Value of this.Users){
            if (Value.ID == ID){
              return Value;
            }
          }
          let Value = this.Real.members.cache.get(ID);
          if (!Value){return}
          Value = FD.new("User",Value);
          this.Users.push(Value);
          return Value;
        },
        GetRolesFromUser:function(User){
          if (!User){return []}
          let u = this.Real.members.cache.get(User.ID);
          if (!u){return []};
          let Roles = [];
          u.roles.cache.each(v=>{
            Roles.push(FD.new("Role",v));
          });
          return Roles;
        },
        GetRole:function(ID){
          for (let Value of this.Roles){
            if (Value.ID == ID){
              return Value;
            }
          }
          let Value = this.Real.roles.cache.find(role => role.id == ID);
          if (!Value){return}
          Value = FD.new("Role",Value);
          this.Roles.push(Value);
          return Value;
        },
        GetChannel:function(ID){
          for (let Value of this.Channels){
            if (Value.ID == ID){
              return Value;
            }
          }
          let Value = this.Real.channels.cache.get(ID);
          if (!Value){return}
          Value = FD.new("Channel",Value);
          this.Channels.push(Value);
          return Value;
        },
        toString:function(){
          return this.Real.toString();
        },
        GetChannels:function(){
          let _ = this;
          this.Real.channels.cache.each(x=>{
            _.GetChannel(x.id);
          });
          return _.Channels;
        },
        GetRoles:function(){
          let _ = this;
          this.Real.roles.cache.each(x=>{
            _.GetRole(x.id);
          });
          return _.Roles;
        },
        GetUsers:function(){
          let _ = this;
          this.Real.members.cache.each(x=>{
            _.GetUser(x.id);
          });
          return _.Users;
        },
      });
      Cache.New("Guild",P);
      return P;
    },
    Channel:function(Real){
      if (!Real){return}
      let Found = Cache.Exists("Channel",Real.id);
      if (Found){return Found}
      if (!(Real instanceof Discord.GuildChannel)){
        Real = Real.fetch().then(v=>{return v}); 
      }
      let P = FD.NewProxy({
        Real:Real,
        ID:Real.id,
        Name:Real.name,
        Guild:FD.new("Guild",Real.guild),
        Type:Real.type,
        IsText:function(){
          return this.Real.isText();
        },
        Send:function(Message){
          if (this.IsText()){
            this.Real.send(Message);
          }
        },
        StartTyping:function(){
          if (this.IsText()){
            this.Real.startTyping();
          }
        },
        StopTyping:function(){
          if (this.IsText()){
            this.Real.stopTyping();
          }
        },
        Join:function(){
          if (!this.IsText()){
            this.Real.join();
          }
        },
        toString:function(){
          return this.Real.toString();
        },
      });
      Cache.New("Channel",P);
      return P;
    },
    User:function(Real){
      if (!Real){return}
      let Found = Cache.Exists("Base",Real.id);
      if (Found){return Found}
      if (Real instanceof Discord.GuildMember){
        Real = Real.user;
      }
      let P = FD.NewProxy({
        Real:Real,
        ID:Real.id,
        Name:Real.username,
        Tag:Real.discriminator,
        FullName:Real.tag,
        Bot:Real.bot,
        Avatar:Real.avatar,
        GetAvatar:function(){
          return this.Real.avatarURL();
        },
        DM:function(Message){
          this.Real.send(Message);
        },
        SetPresence:function(Data){
          this.Real.setPresence(Data);
        },
        toString:function(){
          return this.Real.toString();
        },
      });
      Cache.New("Base",P);
      return P;
    },
    Role:function(Real){
      if (!Real){return}
      let Found = Cache.Exists("Role",Real.id);
      if (Found){return Found}
      let P = FD.NewProxy({
        Real:Real,
        ID:Real.id,
        Name:Real.name,
        Color:Real.color,
        Give:function(User){
          this.Real.guild.members.cache.get(User.ID).roles.add(this.Real)
        },
        toString:function(){
          return this.Real.toString();
        },
      });
      Cache.New("Role",P);
      return P;
    },
    Message:function(Real){
      if (!Real){return}
      let P = FD.NewProxy({
        Real:Real,
        ID:Real.id,
        Content:Real.content,
        Channel:FD.new("Channel",Real.channel),
        Client:CacheClient,
        Guild:FD.new("Guild",Real.guild),
        Author:FD.new("User",Real.author),
        Reply:function(Message){
          this.Real.reply(Message);
        },
        toString:function(){
          return this.Real.toString();
        },
        Delete:function(){
          this.Real.delete();
        },
      });
      return P;
    },
    /*
    Base:function(Real){
      let Found = Cache.Exists("Base",Real.id);
      if (Found){return Found}
      let P = this.NewProxy({
        Real:Real,
        ID:Real.id,
        
      });
      Cache.New("Base",P);
      return P;
    },
    */
    
  },
  new:function(Type,Proxy){
    return this.Types[Type](Proxy);
  },
});

FD.new("Client",DiscordClient);

exports.Client = CacheClient;
exports.MessageEmbed = Discord.MessageEmbed;
exports.New = FD.new.bind(FD);