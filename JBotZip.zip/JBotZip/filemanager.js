const FS = require("fs");

const FileManager = {
	DefaultPath:"",
	SetDefaultPath:function(Path){
		this.DefaultPath=Path;
	},
	ConvertFileDirectory:function(Directory){
		return Directory.match(/^[A-Z]\:/)?Directory:this.DefaultPath+Directory;
	},
	GetFile:function(FileDirectory){
		FileDirectory=this.ConvertFileDirectory(FileDirectory);
		return FS.readFileSync(FileDirectory,"utf-8");
	},
	NewFolder:function(FolderDirectory){
		FolderDirectory=this.ConvertFileDirectory(FolderDirectory);
		return FS.mkdirSync(FolderDirectory);
	},
	RenameDirectory:function(Directory,New){
		Directory=this.ConvertFileDirectory(Directory);
		New=this.ConvertFileDirectory(New);
		return FS.renameSync(Directory,New);
	},
	WriteFile:function(Directory,Data){
		Directory=this.ConvertFileDirectory(Directory);
		return FS.writeFileSync(Directory,Data);
	},
};

for(let Name in FileManager){
	let Value=FileManager[Name];
	//if(typeof Value=="function")Value=Value.bind(FileManager);
	exports[Name]=Value;
}