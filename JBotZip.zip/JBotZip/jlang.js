/*************************\
    Default Environment
\*************************/

const OwnerId = "331260904987688960";
const AllowList = [OwnerId];

const DefaultEnvironment = {
	"_version":"J 1.1",
	"owner":OwnerId,
	"allowList":[...AllowList],
};

/*************************\
       Error Types
\*************************/

const ErrorTypes = {
	"ExpectedGot":(a,b)=>`Expected ${a}, got ${b} instead`,
	"Expected":a=>`Expected ${a}`,
	"ExpectedGotStop":(a,b)=>`Expected ${a}, got ${b}`,
	"Unexpected":a=>`Unexpected ${a}`,
	"Attempt":a=>`Attempt to ${a}`,
	"Cannot":a=>`Cannot ${a}`,
	"Invalid":a=>`Invalid ${a}`,
	"Malformed":a=>`Malformed ${a}`,
	"Halt":a=>`Script halted, ${a}`,
	"Blank":a=>a,
	"NotAllowed":a=>`You are not allowed to ${a}`,
};

class EPXError extends Error{constructor(Name,Message){super(Message).name=Name}}

const ErrorHandler = {
	ThrowError:function(Type,Name="",End="",Arguments=[]){
		let Call = ErrorTypes[Type];
		if(!Call)return;
		throw new EPXError(Name,Call(...Arguments)+End);
	},
	DefaultError:function(Line,Index,Type,Arguments){
		return this.ThrowError(Type,"[J Error]",` on line ${Line} at index ${Index}`,Arguments);
	},
	TokenizerError:function(Token,Type,Arguments){
		return this.DefaultError(Token.Line,Token.Index,Type,Arguments);	
	},
	ASTError:function(Stack,Type,Arguments){
		return this.DefaultError(Stack.Line,Stack.Index,Type,Arguments);	
	},
	InterpreterError:function(Item,Type,Arguments){
		return this.DefaultError(Item.Line,Item.Index,Type,Arguments);	
	},
};

/*************************\
    Epoxy Token Classes
\*************************/

class InternalToken {
	constructor(Name,Literal,Type,Extra={}){
		this.Name=Name,this.Literal=Literal,this.Type=Type;
		for(let Name in Extra)
			this[Name]=Extra[Name];
		this.Extras=Object.keys(Extra);
	}
	equals(Token){
		return Token.Name===this.Name&&Token.Type===this.Type;	
	}
	isType(Type){
		return this.Type===Type;	
	}
	is(Name,Type){
		return Name===this.Name&&Type===this.Type;
	}
}

class BaseToken extends InternalToken {
	constructor(...Arguments){
		super(...Arguments);
		this.Index=0,this.Line=0;
	}
}

/*************************\
     Epoxy Token Types
\*************************/

const TokenTypes = "Keyword Identifier Whitespace Operator Bracket Constant String Number Boolean Null".split(" ");

/*************************\
       Epoxy Tokens
\*************************/

const RawTokens = [
	//Keyword Tokens
	new InternalToken("BREAK","break",TokenTypes[0]),
	new InternalToken("CONTINUE","continue",TokenTypes[0]),
	new InternalToken("REPEAT","repeat",TokenTypes[0]),
	new InternalToken("CMD","cmd",TokenTypes[0]),
	new InternalToken("VAR","var",TokenTypes[0]),
	new InternalToken("CONST","const",TokenTypes[0]),
	new InternalToken("ITERATE","iterate",TokenTypes[0]),
	new InternalToken("IF","if",TokenTypes[0]),
	new InternalToken("ELSE","else",TokenTypes[0]),
	new InternalToken("ELSEIF","elseif",TokenTypes[0]),
	new InternalToken("AS","as",TokenTypes[0]),
	new InternalToken("OF","of",TokenTypes[0]),
	new InternalToken("IN","in",TokenTypes[0]),
	new InternalToken("PORTABLE","portable",TokenTypes[0]),
	new InternalToken("EXECPORTABLE","execportable",TokenTypes[0]),
	//Whitespace Tokens
	new InternalToken("SPACE",String.fromCharCode(32),TokenTypes[2]),
	new InternalToken("TAB",String.fromCharCode(9),TokenTypes[2]),
	new InternalToken("NOBREAKSPACE",String.fromCharCode(160),TokenTypes[2]),
	new InternalToken("OGHAMSPACE",String.fromCharCode(5760),TokenTypes[2]),
	new InternalToken("ENQUAD",String.fromCharCode(8192),TokenTypes[2]),
	new InternalToken("EMQUAD",String.fromCharCode(8193),TokenTypes[2]),
	new InternalToken("ENSPACE",String.fromCharCode(8194),TokenTypes[2]),
	new InternalToken("EMSPACE",String.fromCharCode(8195),TokenTypes[2]),
	new InternalToken("THREEPEMSPACE",String.fromCharCode(8196),TokenTypes[2]),
	new InternalToken("FOURPEMSPACE",String.fromCharCode(8197),TokenTypes[2]),
	new InternalToken("SIXPEMSPACE",String.fromCharCode(8198),TokenTypes[2]),
	new InternalToken("FIGURESPACE",String.fromCharCode(8199),TokenTypes[2]),
	new InternalToken("PUNCSPACE",String.fromCharCode(8200),TokenTypes[2]),
	new InternalToken("THINSPACE",String.fromCharCode(8201),TokenTypes[2]),
	new InternalToken("HAIRSPACE",String.fromCharCode(8202),TokenTypes[2]),
	new InternalToken("NARROWNOBREAKSPACE",String.fromCharCode(8239),TokenTypes[2]),
	new InternalToken("MEDMATHSPACE",String.fromCharCode(8287),TokenTypes[2]),
	new InternalToken("IDEOSPACE",String.fromCharCode(12288),TokenTypes[2]),
	new InternalToken("LINEFEED",String.fromCharCode(10),TokenTypes[2],{LineBreak:true}),
	new InternalToken("LINETAB",String.fromCharCode(11),TokenTypes[2],{LineBreak:true}),
	new InternalToken("FORMFEED",String.fromCharCode(12),TokenTypes[2],{LineBreak:true}),
	new InternalToken("CRETURN",String.fromCharCode(13),TokenTypes[2],{LineBreak:true}),
	new InternalToken("NEXTLINE",String.fromCharCode(133),TokenTypes[2],{LineBreak:true}),
	new InternalToken("LINESEP",String.fromCharCode(8232),TokenTypes[2],{LineBreak:true}),
	new InternalToken("PARASEP",String.fromCharCode(8233),TokenTypes[2],{LineBreak:true}),
	//Operator Tokens
	new InternalToken("COLON",":",TokenTypes[3]),
	new InternalToken("ADD","+",TokenTypes[3]),
	new InternalToken("SUB","-",TokenTypes[3]),
	new InternalToken("MUL","*",TokenTypes[3]),
	new InternalToken("DIV","/",TokenTypes[3]),
	new InternalToken("MOD","%",TokenTypes[3]),
	new InternalToken("POW","^",TokenTypes[3]),
	new InternalToken("DOT",".",TokenTypes[3]),
	new InternalToken("COMMENT","--",TokenTypes[3]),
	new InternalToken("LONGCOMMENTOPEN","--[[",TokenTypes[3]),
	new InternalToken("LONGCOMMENTCLOSE","--]]",TokenTypes[3]),
	new InternalToken("AND","&&",TokenTypes[3]),
	new InternalToken("OR","||",TokenTypes[3]),
	new InternalToken("NOT","!",TokenTypes[3]),
	new InternalToken("EQ","==",TokenTypes[3]),
	new InternalToken("LT","<",TokenTypes[3]),
	new InternalToken("GT",">",TokenTypes[3]),
	new InternalToken("LEQ","<=",TokenTypes[3]),
	new InternalToken("GEQ",">=",TokenTypes[3]),
	new InternalToken("NEQ","!=",TokenTypes[3]),
	new InternalToken("VARARG","...",TokenTypes[3]),
	new InternalToken("LINEEND",";",TokenTypes[3]),
	new InternalToken("COMMA",",",TokenTypes[3]),
	new InternalToken("LENGTH","#",TokenTypes[3]),
	new InternalToken("AT","@",TokenTypes[3]),
	//Bracket Tokens
	new InternalToken("BOPEN","{",TokenTypes[4]),
	new InternalToken("BCLOSE","}",TokenTypes[4]),
	new InternalToken("IOPEN","[",TokenTypes[4]),
	new InternalToken("ICLOSE","]",TokenTypes[4]),
	new InternalToken("POPEN","(",TokenTypes[4]),
	new InternalToken("PCLOSE",")",TokenTypes[4]),
	//String Tokens
	new InternalToken("QUOTE","\"",TokenTypes[6]),
	new InternalToken("APOS","'",TokenTypes[6]),
	//Boolean Tokens
	new InternalToken("TRUE","true",TokenTypes[8]),
	new InternalToken("FALSE","false",TokenTypes[8]),
	//Null Tokens
	new InternalToken("NULL","null",TokenTypes[9]),
	//Control Tokens
	new InternalToken("BACKSLASH","\\","Control"),
];

const JLangTokens = {
	__Tokens:{},
	GetFromName:function(Name,Type){
		let _T=this.__Tokens;
		for(let TN in _T)
			if(TN===Name&&Type===_T[TN].Type)return _T[TN];
	},
	GetFromLiteral:function(Literal,Type){
		let _T=this.__Tokens;
		for(let Name in _T){
			let T = _T[Name];
			if(Literal===T.Literal&&Type===T.Type)return T;
		}
	},
	GetFromRawLiteral:function(Literal){
		let _T=this.__Tokens;
		for(let Name in _T){
			let T = _T[Name];
			if(Literal===T.Literal)return T;
		}
	},
	GetTypeFromName:function(Name){
		let _T=this.__Tokens[Name];
		for(let TN in _T)
			if(Name===TN)return _T[TN].Type;
		return TokenTypes[1];
	},
};
for(let IT of RawTokens)
	JLangTokens.__Tokens[IT.Name]=IT;

/*************************\
      Tokenizer Stack
\*************************/

class TokenizerStack {
	constructor(Code){
		this.Code=Code,
			this.Tokens=Code.split(""),
			this.Result=[],
			this.TokenIndex=0,
			this.TokenLine=1,
			this.Index=0,
			this.Token=this.Tokens[0];
	}
	Next(Amount=1){
		this.Index+=Amount;
		this.Token=this.Tokens[this.Index];
		if(!this.Token)this.Token=Tokenizer.EOSToken;
		return this.Token;
	}
	IsEnd(){
		return this.Index >= this.Tokens.length;
	}
	Write(Token){
		this.Result.push(Token);	
	}
	IsIdentifierCharacter(Character){
		return !!Character.match(/[A-Za-z0-9_]+/);	
	}
	Escape(Literal){
		if(!Literal)return Literal;
		return Literal.replace(/(\<|\>|\*|\(|\)|\{|\}|\[|\]|\||\=|\?|\&|\^|\$|\\|\+|\-|\.|\#)/g, "\\$&");	
	}
	ComputePossibleCharacter(Character){
		let PossibleMatches = [],
			Escape = this.Escape(Character),
			IsIdentifier = false,
			IdentifierLength = 0;
		if(this.IsIdentifierCharacter(Character)){
			let New = Character;
			while(!this.IsEnd()){
				let Next = this.Next();
				if(this.IsEnd())break;
				let EscapeNext = this.Escape(Next);
				if(!this.IsIdentifierCharacter(Next)){
                	this.Next(-1);
                	break;
                }
				New+=Next;
			}
			IsIdentifier=true,
				IdentifierLength=New.length,
				Character=New,
				Escape=this.Escape(New);
		}
		for(let Name in JLangTokens.__Tokens){
			let Token = JLangTokens.__Tokens[Name];
			if(Token.Literal.match(new RegExp(`^${Escape}`))){
				let Matches=0,
					Index=0,
					Length=Token.Literal.length;
				while(true){
					let Value = Token.Literal.substr(Index,1);
					if(Value===this.Tokens[this.Index+Index])Matches++;
					else break;
					Index++;
					if(Index>=Length)break;
				}
				if(Matches===Length){
					PossibleMatches.push(Token.Literal);
					Character=Token.Literal,
						Escape=this.Escape(Character);
				}
			}
		}
		if(PossibleMatches.length===0)PossibleMatches.push(Character);
		let PossibleMatch = PossibleMatches.sort().pop();
		if(!IsIdentifier||PossibleMatch.length!=IdentifierLength)
			this.Next((PossibleMatch.length-IdentifierLength)-1);
		return PossibleMatch;
	}
	ParseToken(Character){
		Character = this.ComputePossibleCharacter(Character);
		let RawToken = JLangTokens.GetFromRawLiteral(Character);
		let Token = new BaseToken(Character,Character,"Identifier");
		if(RawToken){
			Token.Name = RawToken.Name,
				Token.Literal = Character,
				Token.Type = RawToken.Type;
			for(let Name of RawToken.Extras)Token[Name]=RawToken[Name];
		}
		if(Token.Type==="Whitespace"&&Token.LineBreak){
			this.TokenIndex=0,
				this.TokenLine++;
		}
		this.TokenIndex	+= Character.length;
		Token.Index=this.TokenIndex,
			Token.Line=this.TokenLine;
		return Token;
	}
	Parse(){
		while(!this.IsEnd()){
			let Token = this.ParseToken(this.Token);
			if(Token)this.Write(Token);
			this.Next();
		}
		this.Result=this.RemoveWhitespace(this.HandleTokenTypes(this.Result));
	}
	//Whitespace Remover
	RemoveWhitespace(Tokens){
		let Result=[];
		for(let Token of Tokens)if(Token.Type!="Whitespace")Result.push(Token);
		return Result;
	}
	//Token Type Handling
	ParseENumber(Stack,Value,AllowDecimal=true){
		if(Value.toLowerCase().endsWith("e")&&Value.toLowerCase().match(/[0-9](?=e)/)){
			Value=Value.substr(0,Value.length-1);
			if(isNaN(+Value))return[false,Value+"e"];
			let ESuffix = Stack.Next();
			Value+="e";
			if(ESuffix.is("ADD","Operator")||ESuffix.is("SUB","Operator"))
				Value+=ESuffix.Literal,
					ESuffix=Stack.Next();
			if(isNaN(+ESuffix.Literal))return[false,Value+ESuffix.Literal];
			Value+=ESuffix.Literal;
			return [true,Value];
		}else if(AllowDecimal){
			return this.ParseDecimal(Stack,Value);	
		}else{
        		if(!isNaN(+Value)){
            			return [true,Value];
			}
		}
		return [false,Value];
	}
	ParseDecimal(Stack,Value){
		let Next = Stack.Next();
		if(Next&&Next.is("DOT","Operator")){
			let Number = Stack.Next();
			let [Success,Result] = this.ParseENumber(Stack,Number.Literal,false);
			if(!Success)return[Success,Value+"."+Result];
			Value+="."+Result;
		}else{
        		Stack.Next(-1);
        	}
		if(isNaN(+Value))return[false,Value];
		return [true,Value];
	}
	ParseNumber(Stack,Token){
		let [Success,Result] = this.ParseENumber(Stack,Token.Literal);
		return [Success,Result];
	}
	ToNumber(Token,Value){
		Token.Type="Constant",
			Token.Name="Number",
			Token.Literal=Value;
	}
	EscapeStringLiteral(Literal){
		switch (Literal) {
			case "r": return"\r";
			case "n": return"\n";
			case "b": return"\b";
			case "t": return"\t";
			case "c": return"\c";
			case "f": return"\f";
			case "v": return"\v";
			case "t": return"\t";
			default: return Literal;
		}	
	}
	CombineStringLiterals(Literals){
		let Result = "";
		for(let T of Literals){
			let L=T.Literal,
				Add=undefined;
			if(T.Escaped){
				if(L.length>1)Add=L.substr(1,L.length),L=L.substr(0,1);
				L=this.EscapeStringLiteral(L);
			}
			Result+=L;
			if(Add)Result+=Add;
		}
		return Result;
	}
	ParseTokenType(Stack,Token){
		if(Token.isType("Boolean")){
			Token.Type = "Constant",
				Token.Literal = Token.Name==="TRUE"?true:false,
				Token.Name = "Boolean";
		}else if(Token.isType("Null")){
			Token.Type = "Constant",
				Token.Literal = null,
				Token.Name = "Null";
		}else if(Token.isType("Identifier")){
			let Position = Stack.Position;
			let [Success,Result] = this.ParseNumber(Stack,Token);
			if(Success){
				if(isNaN(+Result))return ErrorHandler.TokenizerError(Stack,"Malformed",[`number ${Result}`]);
				this.ToNumber(Token,+Result);
			}else{
				Stack.To(Position);
				if(Result.match(/^[0-9]/))return ErrorHandler.TokenizerError(Stack,"Malformed",[`number ${Result}`]);
			}
		}else if(Token.isType("String")){
			let Result = undefined;
			if(Token.Name==="QUOTE")Result=this.CombineStringLiterals(this.GetBetween(Stack,T=>T.is("QUOTE",Token.Type),true,true));
			else if(Token.Name==="APOS")Result=this.CombineStringLiterals(this.GetBetween(Stack,T=>T.is("APOS",Token.Type),true,true));
			if(!(Result===undefined))Token.Type="Constant",Token.Name="String",Token.Literal=Result;
		}else if(Token.is("COMMENT","Operator")){
			this.GetBetween(Stack,T=>T.Type==="Whitespace"&&T.LineBreak===true);
			return;
		}else if(Token.is("LONGCOMMENTOPEN","Operator")){
			this.GetBetween(Stack,T=>T.is("LONGCOMMENTCLOSE","Operator"),true)
			return;
		}
		return Token;
	}
	GetBetween(Stack,EndCheck,AllowEscapes=false,CheckEOS=false){
		let Result = [];
		while(!Stack.IsEnd()){
			let Token = Stack.Next();
			if(AllowEscapes&&Token.is("BACKSLASH","Control")){
				Token=Stack.Next();
				Token.Escaped===true;
				Result.push(Token);
				continue;
			}
			if(EndCheck(Token))break;
			Result.push(Token);
		}
		if(CheckEOS&&Stack.Token.is("EOS","None"))ErrorHandler.TokenizerError(Stack,"Unexpected",["end of script"]);
		return Result;
	}
	HandleTokenTypes(Tokens){
		let Stack={
			Position:0,
			Tokens:Tokens,
			Token:Tokens[0],
			IndeX:0,
			Line:0,
			Result:[],
			IsEnd:function(){return this.Position>=this.Tokens.length},
			Next:function(Amount=1){this.Position+=Amount;this.Token=this.Tokens[this.Position];if(this.Token)this.Index=this.Token.Index,this.Line=this.Token.Line;else this.Token=Tokenizer.EOSToken;return this.Token},
			Write:function(Token){this.Result.push(Token);return Token},
			To:function(Position){this.Position=Position;this.Token=this.Tokens[this.Position];if(this.Token)this.Index=this.Token.Index,this.Line=this.Token.Line;else this.Token=Tokenizer.EOSToken;return this.Token},
		};
		while(!Stack.IsEnd()){
			let Result = this.ParseTokenType(Stack,Stack.Token);
			if(Result)Stack.Write(Result);
			Stack.Next();
		}
		return Stack.Result;
	}
}

/*************************\
         Tokenizer
\*************************/

const Tokenizer = {
	New:function(...Arguments){
		return new TokenizerStack(...Arguments);
	},
	EOSToken:new InternalToken("EOS","<eos>","None"),
}

/*************************\
         AST Base
\*************************/

class ASTBase {
	constructor(Stack,Type){
		this.Stack=Stack,
			this.Type=Type,
			this.Line=Stack.Line,
			this.Index=Stack.Index,
			this.EndLine=Stack.Line,
			this.EndIndex=Stack.Index;
	}
	Close(){
		this.EndLine=this.Stack.Line,
			this.EndIndex=this.Stack.Index;
	}
}

/*************************\
         AST Node
\*************************/

class ASTNode extends ASTBase {
	constructor(...Arguments){
		super(...Arguments);
		this.Data = {};
	}
	Write(Name,Value){
		this.Data[Name]=Value;
		if(Value instanceof ASTBase)Value.Close();
	}
	Read(Name){
		return this.Data[Name];	
	}
	toString(){
		let Text = [];
		for(let k in this.Data){
			let v = this.Data[k];
			Text.push(`${String(k)}:${String(v)}`);
		}
		return `ASTNode.${this.Type}{${Text.join(", ")}}`;
	}
}

/*************************\
         AST Block
\*************************/

class ASTBlock extends ASTBase {
	constructor(...Arguments){
		super(...Arguments);
		this.Data = [];
	}
	get length(){
		return this.Data.length;	
	}
	Write(Value){
		this.Data.push(Value);
		if(Value instanceof ASTBase)Value.Close();
	}
	Read(Name){
		return this.Data[Name];	
	}
	toString(){
		let Data = [];
		for(let v of this.Data)Data.push(String(v));
		return `ASTBlock.${this.Type}[${Data.join(", ")}]`;
	}
}

/*************************\
    Internal Functions
\*************************/

function ProxyToken(Name,Type){
	return {Name:Name,Type:Type};	
}

/*************************\
          Chunks
\*************************/

const ASTChunks = [
	{
		Name:"BREAK",
		Type:"Keyword",
		Call:function(){
			return this.NewNode("Break");
		},
	},
	{
		Name:"CONTINUE",
		Type:"Keyword",
		Call:function(){
			return this.NewNode("Continue");
		},
	},
	{
		Name:"REPEAT",
		Type:"Keyword",
		Call:function(){
			let Node = this.NewNode("Repeat");
			this.Next();
			Node.Write("Amount",this.ParseExpression());
			this.Next();
			Node.Write("Body",this.ParseBlock(" while parsing repeat loop body"))
			return Node;
		},
	},
	{
		Name:"VAR",
		Type:"Keyword",
		Call:function(){
			this.Next();
			let Node = this.NewNode("NewVariable");
			Node.Write("Variables",this.IdentifierList({
				AllowDefault:true,
				Priority:-1,
				EType:"variable expression",
			}));
			return Node;
		},
	},
	{
		Name:"CONST",
		Type:"Keyword",
		Call:function(){
			this.Next();
			let Node = this.NewNode("NewVariable");
			let Variables = this.IdentifierList({
				AllowDefault:true,
				Priority:-1,
				EType:"variable expression",
			});
			for(let Variable of Variables){
				Variable.Constant = true;	
			}
			Node.Write("Variables",Variables);
			return Node;
		},
	},
	{
		Name:"ITERATE",
		Type:"Keyword",
		Call:function(){
			this.Next();
			let Node = this.NewNode("IterationLoop");
			Node.Write("Variables",this.IdentifierList({AllowDefault:false,AllowPointers:false}));
			this.Next();
			this.ErrorIfEOS(" while parsing iteration loop");
			if(this.Check(this.Token,"IN","Keyword"))Node.Write("Getters",[0]);
			else if(this.Check(this.Token,"OF","Keyword"))Node.Write("Getters",[1]);
			else if(this.Check(this.Token,"AS","Keyword"))Node.Write("Getters",[0,1]);
			else ErrorHandler.ASTError(this,"Unexpected",[`${this.GetFT({UseType:true,UseLiteral:true,Token:this.Token})} while parsing iteration loop`]);
			this.Next();
			Node.Write("Object",this.ParseExpression());
			this.Next();
			Node.Write("Body",this.ParseBlock(" while parsing iteration loop body"));
			return Node;
		},
	},
	{
		Name:"IF",
		Type:"Keyword",
		Call:function(){
			let Node = this.NewNode("If");
			this.Next();
			Node.Write("Expression",this.ParseExpression());
			this.Next();
			this.ErrorIfEOS(" while parsing if statement");
			Node.Write("Body",this.ParseBlock(" while parsing if statement body"));
			let Conditions = [];
			while(this.CheckNext("ELSEIF","Keyword")||this.CheckNext("ELSE","Keyword")){
				if(this.CheckNext("ELSEIF","Keyword")){
					this.Next(2);
					let Condition = this.NewNode("ElseIf");
					Condition.Write("Expression",this.ParseExpression());
					this.Next();
					Condition.Write("Body",this.ParseBlock(" while parsing else-if statement body"));
					Conditions.push(Condition);
				}else if(this.CheckNext("ELSE","Keyword")){
					this.Next(2);
					let Condition = this.NewNode("Else");
					Condition.Write("Body",this.ParseBlock(" while parsing else statement body"));
					Conditions.push(Condition);
				}
				this.ErrorIfEOS(" while parsing if statement");
			}
			Node.Write("Conditions",Conditions);
			/*
			let Conditions = [];
			let Block = undefined,
			    self = this;
			function OpenBlock(){
				let NB = self.OpenChunk();
				if(Block){
					self.OpenChunks.pop();
				}
				Block=NB;
				return NB;
			}
			OpenBlock();
			Block.Type="IfBlock";
			Node.Write("Body",Block);
			while(!this.Token.is("CLOSE","Keyword")){
				let Token = this.Token;
				if(Token.is("ELSEIF","Keyword")){
					OpenBlock();
					Block.Type="IfBlock";
					this.Next();
					let Condition = this.NewNode("ElseIf");
					Condition.Write("Expression",this.ParseExpression());
					this.Next();
					Condition.Write("Body",Block);
					Conditions.push(Condition);
				}else if(Token.is("ELSE","Keyword")){
					OpenBlock();
					Block.Type="IfBlock";
					this.Next();
					let Condition = this.NewNode("Else");
					Condition.Write("Body",Block);
					Conditions.push(Condition);
				}else{
					this.ParseChunk();
					this.Next();
				}
				this.ErrorIfEOS(" while parsing if statement");
			}
			Node.Write("Conditions",Conditions);
			this.Chunk=this.OpenChunks.pop();
			*/
			return Node;
		},
	},
	/*
	{
		Name:"Name",
		Type:"Type",
		Call:function(){
			let Node = this.NewNode("Type");
			
			return Node;
		},
	},
	*/
];

/*************************\
        Expressions
\*************************/

const ASTExpressions = [
	{
		Type:"Constant",
		Stop:false,
		Call:function(Priority,AllowList,Type){
			return this.ASTExpression(this.Token.Literal,Priority);
		},
	},
	{
		Type:"Identifier",
		Stop:false,
		Call:function(Priority,AllowList,Type){
			let Node = this.NewNode("GetVariable");
			Node.Write("Name",this.Token.Literal);
			return this.ASTExpression(Node,Priority);
		},
	},
	{
		Name:"POPEN",
		Type:"Bracket",
		Stop:false,
		Call:function(Priority,AllowList,Type){
			this.Next();
			let Node = this.ParseExpression(-1);
			this.TestNext("PCLOSE","Bracket");
			this.Next();
			return this.ASTExpression(Node,Priority);
		},
	},
	{
		Name:"LINEEND",
		Type:"Operator",
		Stop:false,
		Call:function(Priority,AllowList,Type){
			return this.ASTExpression(null,Priority);
		},
	},
	{
		Name:"NOT",
		Type:"Operator",
		Stop:false,
		Call:function(Priority,AllowList,Type){
			this.Next();
			let Node = this.NewNode("Not");
			Node.Write("V1",this.ParseExpression(400));
			return this.ASTExpression(Node,Priority);
		},
	},
	{
		Name:"SUB",
		Type:"Operator",
		Stop:false,
		Call:function(Priority,AllowList,Type){
			this.Next();
			let Node = this.NewNode("Negative");
			Node.Write("V1",this.ParseExpression(400));
			return this.ASTExpression(Node,Priority);
		},
	},
	{
		Name:"LENGTH",
		Type:"Operator",
		Stop:false,
		Call:function(Priority,AllowList,Type){
			this.Next();
			let Node = this.NewNode("Length");
			Node.Write("V1",this.ParseExpression(400));
			return this.ASTExpression(Node,Priority);
		},
	},
	{
		Name:"IOPEN",
		Type:"Bracket",
		Stop:false,
		Call:function(Priority,AllowList,Type){
			let Node = this.NewNode("Array");
			Node.Write("List",this.ExpressionListInside({Name:"IOPEN",Type:"Bracket"},{Name:"ICLOSE",Type:"Bracket"}));
			return this.ASTExpression(Node,Priority);
		},
	},
	{
		Name:"BOPEN",
		Type:"Bracket",
		Stop:false,
		Call:function(Priority,AllowList,Type){
			let Node = this.NewNode("Object");
			Node.Write("Object",this.IdentifierListInside(ProxyToken("BOPEN","Bracket"),ProxyToken("BCLOSE","Bracket"),{
				AllowDefault:true,
				AllowExpression:true,
				AllowKeywords:true,
			}));
			return this.ASTExpression(Node,Priority);
		},
	},
	{
		Name:"VARARG",
		Type:"Operator",
		Stop:false,
		Call:function(Priority,AllowList,Type){
			let Node = this.NewNode("Unpack");
			this.Next();
			Node.Write("List",this.ParseExpression());
			return this.ASTExpression(Node,Priority);
		},
	},
	{
		Name:"LT",
		Type:"Operator",
		Stop:false,
		Call:function(Priority,AllowList,Type){
			let Node = this.NewNode("None");
			if(this.CheckNext("AT","Operator")){
				Node.Type="GetUser";
			}else if(this.CheckNext("LENGTH","Operator")){
				Node.Type="GetChannel";
			}else{
				ErrorHandler.ASTError(this,"Expected",["@ or # for pinging users or linking channels"])
			}
			this.Next();
			this.TypeTestNext("Constant");
			this.Next();
			Node.Write("Id",this.Token.Literal);
			this.TestNext("GT","Operator");
			this.Next();
			return this.ASTExpression(Node,Priority);
		},
	},
	{
		Name:"PORTABLE",
		Type:"Keyword",
		Stop:false,
		Call:function(Priority,AllowList,Type){
			let Node = this.NewNode("Portable");
			this.Next();
			Node.Write("Body",this.ParseBlock(" while parsing portable statement body"));
			return this.ASTExpression(Node,Priority);
		},
	},
	{
		Name:"EXECPORTABLE",
		Type:"Keyword",
		Stop:false,
		Call:function(Priority,AllowList,Type){
			let Node = this.NewNode("ExecutePortable");
			this.Next();
			Node.Write("Portable",this.ParseExpression(400));
			return this.ASTExpression(Node,Priority);
		},
	},
	{
		Name:"CMD",
		Type:"Keyword",
		Stop:false,
		Call:function(Priority,AllowList,Type){
			let Node = this.NewNode("Command");
			this.TypeTestNext("Identifier");
			this.Next();
			Node.Write("Command",this.Token.Literal);
			this.Next();
			if(!this.Token)Node.Write("Parameters",[]);
			else Node.Write("Parameters",this.ExpressionList());
			return this.ASTExpression(Node,Priority);
		},
	},
	/*
	{
		Name:"Name",
		Type:"Type",
		Stop:false,
		Call:function(Priority,AllowList,Type){
			let Node = this.NewNode("Type");
			
			return this.ASTExpression(Node,Priority);
		},
	},
	*/
];

/*************************\
    Complex Expressions
\*************************/

const ASTComplexExpressions = [
	{
		Name:"SUB",
		Type:"Operator",
		Stop:false,
		Priority:300,
		Call:function(Value,Priority,AllowList,Type){
			this.Next(2);
			let Node = this.NewNode("Sub");
			Node.Write("V1",Value);
			if(this.Check(this.Token,"COLON","Operator")){
				if(!(Value instanceof ASTBase)||(Value.Type!="GetVariable"&&Value.Type!="GetIndex"))ErrorHandler.ASTError(this,"Expected",["identifier or index for assignment"]);
				Node.Type = "Assignment";
				this.Next();
				Node.Write("Type",2);
				Node.Write("Name",Value);
				Node.Write("Value",this.ParseExpression());
				return this.ASTExpression(Node,Priority);
			}
			Node.Write("V2",this.ParseExpression(Priority));
			return this.ASTExpression(Node,Priority);
		},
	},
	{
		Name:"ADD",
		Type:"Operator",
		Stop:false,
		Priority:320,
		Call:function(Value,Priority,AllowList,Type){
			this.Next(2);
			let Node = this.NewNode("Add");
			if(this.Check(this.Token,"COLON","Operator")){
				if(!(Value instanceof ASTBase)||(Value.Type!="GetVariable"&&Value.Type!="GetIndex"))ErrorHandler.ASTError(this,"Expected",["identifier or index for assignment"]);
				Node.Type = "Assignment";
				this.Next();
				Node.Write("Type",1);
				Node.Write("Name",Value);
				Node.Write("Value",this.ParseExpression());
				return this.ASTExpression(Node,Priority);
			}
			Node.Write("V1",Value);
			Node.Write("V2",this.ParseExpression(Priority));
			return this.ASTExpression(Node,Priority);
		},
	},
	{
		Name:"MUL",
		Type:"Operator",
		Stop:false,
		Priority:360,
		Call:function(Value,Priority,AllowList,Type){
			this.Next(2);
			let Node = this.NewNode("Mul");
			if(this.Check(this.Token,"COLON","Operator")){
				if(!(Value instanceof ASTBase)||(Value.Type!="GetVariable"&&Value.Type!="GetIndex"))ErrorHandler.ASTError(this,"Expected",["identifier or index for assignment"]);
				Node.Type = "Assignment";
				this.Next();
				Node.Write("Type",3);
				Node.Write("Name",Value);
				Node.Write("Value",this.ParseExpression());
				return this.ASTExpression(Node,Priority);
			}
			Node.Write("V1",Value);
			Node.Write("V2",this.ParseExpression(Priority));
			return this.ASTExpression(Node,Priority);
		},
	},
	{
		Name:"DIV",
		Type:"Operator",
		Stop:false,
		Priority:340,
		Call:function(Value,Priority,AllowList,Type){
			this.Next(2);
			let Node = this.NewNode("Div");
			if(this.Check(this.Token,"COLON","Operator")){
				if(!(Value instanceof ASTBase)||(Value.Type!="GetVariable"&&Value.Type!="GetIndex"))ErrorHandler.ASTError(this,"Expected",["identifier or index for assignment"]);
				Node.Type = "Assignment";
				this.Next();
				Node.Write("Type",4);
				Node.Write("Name",Value);
				Node.Write("Value",this.ParseExpression());
				return this.ASTExpression(Node,Priority);
			}
			Node.Write("V1",Value);
			Node.Write("V2",this.ParseExpression(Priority));
			return this.ASTExpression(Node,Priority);
		},
	},
	{
		Name:"MOD",
		Type:"Operator",
		Stop:false,
		Priority:340,
		Call:function(Value,Priority,AllowList,Type){
			this.Next(2);
			let Node = this.NewNode("Mod");
			if(this.Check(this.Token,"COLON","Operator")){
				if(!(Value instanceof ASTBase)||(Value.Type!="GetVariable"&&Value.Type!="GetIndex"))ErrorHandler.ASTError(this,"Expected",["identifier or index for assignment"]);
				Node.Type = "Assignment";
				this.Next();
				Node.Write("Type",5);
				Node.Write("Name",Value);
				Node.Write("Value",this.ParseExpression());
				return this.ASTExpression(Node,Priority);
			}
			Node.Write("V1",Value);
			Node.Write("V2",this.ParseExpression(Priority));
			return this.ASTExpression(Node,Priority);
		},
	},
	{
		Name:"POW",
		Type:"Operator",
		Stop:false,
		Priority:380,
		Call:function(Value,Priority,AllowList,Type){
			this.Next(2);
			let Node = this.NewNode("Pow");
			if(this.Check(this.Token,"COLON","Operator")){
				if(!(Value instanceof ASTBase)||(Value.Type!="GetVariable"&&Value.Type!="GetIndex"))ErrorHandler.ASTError(this,"Expected",["identifier or index for assignment"]);
				Node.Type = "Assignment";
				this.Next();
				Node.Write("Type",6);
				Node.Write("Name",Value);
				Node.Write("Value",this.ParseExpression());
				return this.ASTExpression(Node,Priority);
			}
			Node.Write("V1",Value);
			Node.Write("V2",this.ParseExpression(Priority));
			return this.ASTExpression(Node,Priority);
		},
	},
	{
		Name:"IOPEN",
		Type:"Bracket",
		Stop:false,
		Priority:700,
		Call:function(Value,Priority,AllowList,Type){
			this.Next(2);
			let Node = this.NewNode("GetIndex");
			Node.Write("Object",Value);
			Node.Write("Index",this.ParseExpression(-1));
			this.TestNext("ICLOSE","Bracket");
			this.Next();
			return this.ASTExpression(Node,Priority);
		},
	},
	{
		Name:"DOT",
		Type:"Operator",
		Stop:false,
		Priority:700,
		Call:function(Value,Priority,AllowList,Type){
			this.Next(2);
			let Node = this.NewNode("GetIndex");
			Node.Write("Object",Value);
			let Token = this.Token;
			if(!Token.isType("Identifier")&&!Token.isType("Keyword"))ErrorHandler.ASTError(this,"ExpectedGot",["identifier for index name",this.GetFT({UseType:true,UseLiteral:true,Token:Token})]);
			Node.Write("Index",Token.Literal);
			return this.ASTExpression(Node,Priority);
		},
	},
	{
		Name:"COLON",
		Type:"Operator",
		Stop:true,
		Priority:50,
		Call:function(Value,Priority,AllowList,Type){
			if(!(Value instanceof ASTBase)||(Value.Type!="GetVariable"&&Value.Type!="GetIndex"))ErrorHandler.ASTError(this,"Expected",["identifier or index for assignment"]);
			this.Next(2);
			let Node = this.NewNode("Assignment");
			Node.Write("Type",0);
			Node.Write("Name",Value);
			Node.Write("Value",this.ParseExpression());
			return this.ASTExpression(Node,Priority);
		},
	},
	{
		Name:"POPEN",
		Type:"Bracket",
		Stop:false,
		Priority:1000,
		Call:function(Value,Priority,AllowList,Type){
			this.Next();
			let Node = this.NewNode("Call");
			Node.Write("Call",Value);
			Node.Write("Arguments",this.ExpressionListInside({Name:"POPEN",Type:"Bracket"},{Name:"PCLOSE",Type:"Bracket"}));
			return this.ASTExpression(Node,Priority);
		},
	},
	{
		Name:"EQ",
		Type:"Operator",
		Stop:false,
		Priority:200,
		Call:function(Value,Priority,AllowList,Type){
			this.Next(2);
			let Node = this.NewNode("Eq");
			Node.Write("V1",Value);
			Node.Write("V2",this.ParseExpression(Priority));
			return this.ASTExpression(Node,Priority);
		},
	},
	{
		Name:"LT",
		Type:"Operator",
		Stop:false,
		Priority:200,
		Call:function(Value,Priority,AllowList,Type){
			this.Next(2);
			let Node = this.NewNode("Lt");
			Node.Write("V1",Value);
			Node.Write("V2",this.ParseExpression(Priority));
			return this.ASTExpression(Node,Priority);
		},
	},
	{
		Name:"LEQ",
		Type:"Operator",
		Stop:false,
		Priority:200,
		Call:function(Value,Priority,AllowList,Type){
			this.Next(2);
			let Node = this.NewNode("Leq");
			Node.Write("V1",Value);
			Node.Write("V2",this.ParseExpression(Priority));
			return this.ASTExpression(Node,Priority);
		},
	},
	{
		Name:"GT",
		Type:"Operator",
		Stop:false,
		Priority:200,
		Call:function(Value,Priority,AllowList,Type){
			this.Next(2);
			let Node = this.NewNode("Gt");
			Node.Write("V1",Value);
			Node.Write("V2",this.ParseExpression(Priority));
			return this.ASTExpression(Node,Priority);
		},
	},
	{
		Name:"GEQ",
		Type:"Operator",
		Stop:false,
		Priority:200,
		Call:function(Value,Priority,AllowList,Type){
			this.Next(2);
			let Node = this.NewNode("Geq");
			Node.Write("V1",Value);
			Node.Write("V2",this.ParseExpression(Priority));
			return this.ASTExpression(Node,Priority);
		},
	},
	{
		Name:"NEQ",
		Type:"Operator",
		Stop:false,
		Priority:200,
		Call:function(Value,Priority,AllowList,Type){
			this.Next(2);
			let Node = this.NewNode("Neq");
			Node.Write("V1",Value);
			Node.Write("V2",this.ParseExpression(Priority));
			return this.ASTExpression(Node,Priority);
		},
	},
	{
		Name:"AND",
		Type:"Operator",
		Stop:false,
		Priority:150,
		Call:function(Value,Priority,AllowList,Type){
			this.Next(2);
			let Node = this.NewNode("And");
			Node.Write("V1",Value);
			Node.Write("V2",this.ParseExpression(Priority));
			return this.ASTExpression(Node,Priority);
		},
	},
	{
		Name:"OR",
		Type:"Operator",
		Stop:false,
		Priority:151,
		Call:function(Value,Priority,AllowList,Type){
			this.Next(2);
			let Node = this.NewNode("Or");
			Node.Write("V1",Value);
			Node.Write("V2",this.ParseExpression(Priority));
			return this.ASTExpression(Node,Priority);
		},
	},
	/*
	
	*/
	/*
	{
		Name:"Name",
		Type:"Type",
		Stop:false,
		Priority:0,
		Call:function(Value,Priority,AllowList,Type){
			let Node = this.NewNode("Type");
			
			return this.ASTExpression(Node,Priority);
		},
	},
	*/
];


class ASTExpression {
	constructor(Value,Priority=-1){
			this.Value=Value,this.Priority=Priority;
	}
}

/*************************\
         AST Stack
\*************************/

class ASTStack {
	//{{ Constructor }}\\
	constructor(TokenizerStack){
		this.TokenizerStack=TokenizerStack,
			this.Tokens=TokenizerStack.Result,
			this.Position=0,
			this.Token=this.Tokens[0],
			this.Line=this.Token?this.Token.Line:0,
			this.Index=this.Token?this.Token.Index:0,
			this.Result=this.NewBlock("Chunk"),
			this.Chunk=this.Result,
			this.OpenChunks=[];
	}
	//{{ AST Classes }}\\
	NewNode(Type){
		return new ASTNode(this,Type);	
	}
	NewBlock(Type){
		return new ASTBlock(this,Type);	
	}
	//{{ Chunk Handling }}\\
	OpenChunk(){
		this.OpenChunks.push(this.Chunk);
		this.Chunk = this.NewBlock("Chunk");
		return this.Chunk;
	}
	ChunkWrite(Value){
		this.Chunk.Write(Value);	
	}
	CloseChunk(){
		if(this.OpenChunks.length>0){
			let Previous=this.Chunk;
			this.Chunk=this.OpenChunks.pop();
			this.Chunk.Write(Previous);
		}
	}
	//{{ Control Methods }}\\
	Next(Amount=1){
		this.Position+=Amount;
		this.Token=this.Tokens[this.Position];
		if(this.Token)this.Line=this.Token.Line,this.Index=this.Token.Index;	
		return this.Token;
	}
	To(Position){
		this.Position=Position;
		this.Token=this.Tokens[this.Position];
		if(this.Token)this.Line=this.Token.Line,this.Index=this.Token.Index;	
		return this.Token;
	}
	IsEnd(){
		return this.Position>=this.Tokens.length;
	}
	//{{ Token Naming Methods }}\\
	GetFT(Options={}){
		if(this.IsEnd()&&(!Options.Tokens&&!Options.Type))return "end of script";
		let Type = Options.Token?Options.Token.Type:Options.Type,
			Literal = Options.Token?Options.Token.Literal:Options.Literal,
			Name = Options.Token?Options.Token.Name:Options.Name;
		if(Type==="Constant")Type=Name.toLowerCase();
		let Text=[];
		if(Options.UseType)Text.push(Type.toLowerCase());
		if(Options.UseLiteral)Text.push(Literal);
		return Text.join(" ");
	}
	//{{ Token Checking Methods }}\\
	Check(Token,Name,Type){
		if(!Token)return false;
		return Token.is(Name,Type);
	}
	TypeCheck(Token,Type){
		if(!Token)return false;
		return Token.isType(Type);
	}
	CheckNext(Name,Type){
		if(!this.Token)return false;
		let Next=this.Next();
		this.Next(-1);
		if(!Next)return false;
		return this.Check(Next,Name,Type)
	}
	TypeCheckNext(Type){
		if(!this.Token)return false;
		let Next=this.Next();
		this.Next(-1);
		if(!Next)return false;
		return this.TypeCheck(Next,Type);
	}
	ErrorIfEOS(Type=""){
		if(this.IsEnd())ErrorHandler.ASTError(this,"Unexpected",["end of script"+Type]);
	}
	Test(Token,Name,Type){
		if(!this.Check(Token,Name,Type)){
			let T = JLangTokens.GetFromName(Name,Type);
			ErrorHandler.ASTError(this,"ExpectedGot",[this.GetFT({UseType:true,UseLiteral:true,Type:Type,Name:Name,Literal:T?T.Literal:Name}),this.GetFT({UseType:true,UseLiteral:true,Token:this.Token})]);
		}
	}
	TypeTest(Token,Type){
		if(!this.TypeCheck(Token,Type)){
			ErrorHandler.ASTError(this,"ExpectedGot",[this.GetFT({UseType:true,UseLiteral:false,Type:Type}),this.GetFT({UseType:true,UseLiteral:false,Token:this.Token})]);
		}
	}
	TestNext(Name,Type){
		if(!this.CheckNext(Name,Type)){
			this.Next();
			let T = JLangTokens.GetFromName(Name,Type);
			ErrorHandler.ASTError(this,"ExpectedGot",[this.GetFT({UseType:true,UseLiteral:true,Type:Type,Name:Name,Literal:T?T.Literal:Name}),this.GetFT({UseType:true,UseLiteral:true,Token:this.Token})]);
		}
	}
	TypeTestNext(Type){
		if(!this.TypeCheckNext(Type)){
			this.Next();
			ErrorHandler.ASTError(this,"ExpectedGot",[this.GetFT({UseType:true,UseLiteral:false,Type:Type}),this.GetFT({UseType:true,UseLiteral:false,Token:this.Token})]);
		}
	}
	//{{ Expressional Parsing Methods }}\\
	ASTExpression(...Arguments){
		return new ASTExpression(...Arguments);	
	}
	ParseComplexExpression(Expression,AllowList=[],Type="complex expression"){
		if(!(Expression instanceof ASTExpression))return Expression;
		let Priority=Expression.Priority,
			Next=this.Tokens[this.Position+1],
			Current=this.Token;
		if(!Next)return Expression.Value;
		if(Next.is("LINEEND","Operator"))return Expression.Value;
		//if(Next.isType("Identifier")&&Current.isType("Identifier"))ErrorHandler.ASTError(this,"Unexpected",[`identifier while parsing ${Type}`]);
		let Allowed=AllowList.length>0,
			Passed=false;
		if(Allowed){
			for(let Allow of AllowList){
				if(Next.is(...Allow)){
					Passed=true;
					break;
				}
			}
			if(!Passed){
				let Valid=false;
				for(let CE of ASTComplexExpressions)
					if(Next.is(CE.Name,CE.Type)){
						Valid=true;
						break
					}
				Passed=!Valid;
			}
			if(!Passed)return ErrorHandler.ASTError(this,"Unexpected",[`${this.GetFT({UseType:true,UseLiteral:true,Token:Next})} while parsing ${Type}`]);
		}
		for(let ComplexExpression of ASTComplexExpressions){
			if(!Next.is(ComplexExpression.Name,ComplexExpression.Type))continue;
			if(Expression.Priority<=ComplexExpression.Priority){
				Expression = ComplexExpression.Call.bind(this)(Expression.Value,ComplexExpression.Priority,AllowList,Type);
				Expression.Priority = Priority;
				if(ComplexExpression.Stop===true)break;
				if(Expression.Value instanceof ASTBase&&Expression.Value.Type==="Assignment")return Expression.Value;
				let Result=this.ParseComplexExpression(Expression,AllowList,Type);
				return Result;
			}
		}
		return Expression.Value;
	}
	ParseExpression(Priority=-1,AllowList,Type,EAllowList=[],EType="expression"){
		this.ErrorIfEOS();
		let Token=this.Token,
			Result=undefined;
		let Allowed=EAllowList.length>0;
		for(let Expression of ASTExpressions){
			let Do=false,TY="Value";
			if(Expression.Name)Do=Token.is(Expression.Name,Expression.Type),TY="Value";
			else Do=Token.isType(Expression.Type),TY="Type";
			if(Do){
				if(Allowed){
					let Passed=false;
					for(let Allow of EAllowList){
						if(TY==="Value"&&Allow.length==2)Passed=Token.is(...Allow);
						else if(TY==="Type"&&Allow.length==1) Passed=Token.isType(...Allow);
						if(Passed)break;
					}
					if(!Passed)return ErrorHandler.ASTError(this,"Unexpected",[`${this.GetFT({UseType:true,UseLiteral:true,Token:Token})} while parsing ${EType}`]);
				}
				let Exp = Expression.Call.bind(this)(Priority,AllowList,Type);
				Result = Exp.Value;
				Priority = Exp.Priority;
				if(Expression.Stop===true)return Result;
				break;
			}
		}
		if(Result===undefined)ErrorHandler.ASTError(this,"Unexpected",[`${this.GetFT({UseType:true,UseLiteral:true,Token:Token})} while parsing ${EType}`]);
		Result = this.ParseComplexExpression(new ASTExpression(Result,Priority),AllowList,Type);
		return Result;
	}
	ExpressionList(Priority,AllowList,Type,End,EAllowList,EType){
		let List=[];
		do {
			List.push(this.ParseExpression(Priority,AllowList,Type,EAllowList,EType));
			if(this.CheckNext("COMMA","Operator")){
				this.Next(2);
				if(End&&this.Token&&this.Token.is(End.Name,End.Type)){
					End.Stopped=true;
					break;
				}
				continue;
			}
			break;
		}while(true);
		return List;
	}
	ExpressionListInside(Start,End,Priority,AllowList,Type,EAllowList,EType){
		this.ErrorIfEOS(" while parsing expression list");
		if(this.Token.is(Start.Name,Start.Type)){
			this.Next();
			this.ErrorIfEOS(" while parsing expression list");
			if(this.Token.is(End.Name,End.Type))return[];
			let List = this.ExpressionList(Priority,AllowList,Type,End,EAllowList,EType);
			if(!End.Stopped)this.TestNext(End.Name,End.Type),this.Next();
			return List;
		}else{
			let T = JLangTokens.GetFromName(Start.Name,Start.Type);
			ErrorHandler.ASTError(this,"ExpectedGot",[this.GetFT({UseType:true,UseLiteral:true,Type:T.Type,Name:T.Name,Literal:T?T.Literal:T.Literal}),this.GetFT({UseType:true,UseLiteral:true,Token:this.Token})]);
		}
	}
	ExpressionInside(Start,End,Priority,AllowList,Type,EAllowList,EType){
		if(this.Token.is(Start.Name,Start.Type)){
			this.Next();
			this.ErrorIfEOS(" while parsing expression");
			if(this.Token.is(End.Name,End.Type))return;
			let Result = this.ParseExpression(Priority,AllowList,Type,End,EAllowList,EType);
			this.TestNext(End.Name,End.Type);
			this.Next();
			return Result;
		}else{
			let T = JLangTokens.GetFromName(Start.Name,Start.Type);
			ErrorHandler.ASTError(this,"ExpectedGot",[this.GetFT({UseType:true,UseLiteral:true,Type:T.Type,Name:T.Name,Literal:T?T.Literal:T.Literal}),this.GetFT({UseType:true,UseLiteral:true,Token:this.Token})]);
		}
	}
	//{{ Identifier Parsing Methods }}\\
	IdentifierList(Options,End){
		let List = [];
		this.ErrorIfEOS(" while parsing identifier list");
		this.Chunk.IdentifierList = true;
		do{
			let Identifier = {
				Name:undefined,
				Value:undefined,
				Line:this.Token.Line,
				Index:this.Token.Index,
				Pointer:undefined,
				Vararg:false,
			}
			let Run = true;
			if(Options.Modifiers&&Options.Modifiers.length>0){
				for(let Modifier of Options.Modifiers){
					if(Modifier.Check(this,Options,Identifier)){
						Modifier.Call(this,Options,Identifier);
						Run=false;
						break;
					}
				}
			}
			if(Run){
				if(Options.AllowPointer){
					this.Test(this.Token,"POPEN","Bracket");
					this.Next();
					this.TypeTest(this.Token,"Identifier");
					Identifier.Pointer = this.Token.Name;
					this.TestNext("PCLOSE","Bracket");
					this.Next(2);
				}
				if(Options.AllowVararg){
					if(this.Check(this.Token,"VARARG","Operator")){
						this.Next();
						Identifier.Vararg=true;
					}
				}
				if(Options.AllowExpression&&this.Check(this.Token,"IOPEN","Bracket")){
					this.Next();
					Identifier.Name = this.ParseExpression();
					this.TestNext("ICLOSE","Bracket");
					this.Next();
				}else{
					let WasKeyword=false;
					if(Options.AllowKeywords){
						if(this.Token.Type==="Keyword"){
							Identifier.Name = this.Token.Literal;
							WasKeyword=true;
						}
					}
					if(!WasKeyword){
						this.TypeTest(this.Token,"Identifier");
						Identifier.Name = this.Token.Name;
					}
				}
				if(Options.AllowDefault){
					if(this.CheckNext("COLON","Operator")){
						this.Next(2);
						Identifier.Value = this.ParseExpression(Options.Priority,Options.AllowList,Options.Type,Options.EAllowList,Options.EType);
					}
				}
			}
			List.push(Identifier);
			if(this.CheckNext("COMMA","Operator")){
				this.Next(2);
				if(End&&this.Token&&this.Token.is(End.Name,End.Type)){
					End.Stopped=true;
					break;
				}
				continue;
			}
			break;
		}while(true);
		delete this.Chunk.IdentifierList;
		return List;
	}
	IdentifierListInside(Start,End,Options){
		this.ErrorIfEOS(" while parsing identifier list");
		if(this.Token.is(Start.Name,Start.Type)){
			this.Next();
			this.ErrorIfEOS(" while parsing identifier list");
			if(this.Token.is(End.Name,End.Type))return[];
			let List = this.IdentifierList(Options,End);
			if(!End.Stopped)this.TestNext(End.Name,End.Type),this.Next();
			return List;
		}else{
			let T = _Tokens.GetFromName(Start.Name,Start.Type);
			ErrorHandler.ASTError(this,"ExpectedGot",[this.GetFT({UseType:true,UseLiteral:true,Type:T.Type,Name:T.Name,Literal:T?T.Literal:T.Literal}),this.GetFT({UseType:true,UseLiteral:true,Token:this.Token})]);
		}
	}
	//{{ Chunk Parsing Methods }}\\
	ParseBlock(Type=" while parsing chunk"){
		let Block=this.OpenChunk();
		this.ErrorIfEOS(Type);
		if(this.Token.is("BOPEN","Bracket")){
			this.Next();
			while(!this.Token.is("BCLOSE","Bracket")){
				this.ParseChunk();
				this.Next();
				this.ErrorIfEOS(Type);
			}
		}else{
			this.ParseChunk();
		}
		this.Chunk = this.OpenChunks.pop();
		return Block;
	}
	SkipLineEnd(){
		if(this.CheckNext("LINEEND","Operator"))this.Next();	
	}
	ParseRChunk(){
		let Token=this.Token;
		for(let Chunk of ASTChunks){
			if(Token.is(Chunk.Name,Chunk.Type)){
				let Result = Chunk.Call.bind(this)();
				return Result;
			}
		}	
	}
	ParseChunk(){
		let Token=this.Token;
		for(let Chunk of ASTChunks){
			if(Token.is(Chunk.Name,Chunk.Type)){
				let Result = Chunk.Call.bind(this)();
				this.SkipLineEnd();
				this.ChunkWrite(Result);
				return;
			}
		}
		let Result = this.ParseExpression();
		if(Result===undefined)ErrorHandler.ASTError(this,"Unexpected",[this.GetFT({UseType:true,UseLiteral:true,Token:Token})]);
		this.SkipLineEnd();
		this.ChunkWrite(Result);
		//ErrorHandler.ASTError(this,"Unexpected",[this.GetFT({UseType:true,UseLiteral:true,Token:Token})]);
	}
	Parse(){
		while(!this.IsEnd())
			this.ParseChunk(),this.Next();
	}
}

/*************************\
            AST
\*************************/

const AST = {
	New:function(TokenizerStack){
		return new ASTStack(TokenizerStack);
	},
}

/*************************\
     Epoxy State Data
\*************************/

const StatePropagation = {
	OnWrite:[
		{
			Names:["Break","Continue"],
			Check:(c,p)=>c.Read("IsLoop")!=true,
		},
		{
			Names:["Thread"],
			Check:(c,p)=>c.Read("IsFunction")!=true,
		},
	],
	OnGlobalRead:[
		{
			Names:["Thread"],
			Check:(c,p)=>c.Read("IsFunction")!=true,
		},
	],
}

/*************************\
        Epoxy State
\*************************/

class EpoxyState {
	constructor(Body,Parent,Extra={}){
		this.Token=Body.Data[0],
			this.Tokens=Body,
			this.Parent=Parent,
			this.Data={
				IsFunction:false,
				IsLoop:false,
				Break:false,
				Continue:false,
			},
			this.Variables=[],
			this.Children=[],
			this.Position=0,
			this.Line=0,
			this.Index=0,
			this.Results=[];
		for(let Name in Extra)this.Data[Name]=Extra[Name];
		if(Parent&&Parent instanceof EpoxyState)Parent.Children.push(this);
		if(this.Token)this.Line=this.Token.Line,this.Index=this.Token.Index;
		else if(this.Parent&&this.Parent.Token)this.Line=this.Parent.Token.Line,this.Index=this.Parent.Token.Index;
	}
	Write(Name,Value){
		this.Data[Name]=Value;
		if(this.Parent)
			for(let Property of StatePropagation.OnWrite){
				let {Names,Check}=Property;
				if(Names.includes(Name)&&Check(this,this.Parent))this.Parent.Write(Name,Value);
			}
	}
	Read(Name){
		return this.Data[Name];	
	}
	GlobalRead(Name){
		let Value = this.Read(Name);
		if(Value===undefined&&this.Parent){
			for(let Property of StatePropagation.OnGlobalRead){
				let {Names,Check}=Property;
				if(Names.includes(Name)&&Check(this,this.Parent)){
					Value = this.Parent.GlobalRead(Name);
					break;
				}
			}
		}
		return Value;
	}
	Next(Amount=1){
		this.Position+=Amount;
		this.Token=this.Tokens.Data[this.Position];
		if(this.Token)this.Index=this.Token.Index,this.Line=this.Token.Line;
		return this.Token
	}
	IsEnd(){
		return this.Position >= this.Tokens.Data.length;	
	}
	Close(){
		if(this.Parent)this.Parent.Children.splice(this.Parent.Children.indexOf(this),1);
		let Variables=this.GetGlobalVariables();
		for(let Child of this.Children){
			for(let Variable of Variables)Child.TransferVariable(Variable);
			Child.Parent=undefined;
		}
		this.Variables=[];
	}
	TransferVariable(Variable){
		if(!this.IsVariable(Variable.Name))this.Variables.push(Variable);	
	}
	GetGlobalVariables(){
		let Variables=[],
			Search=this;
		while(Search){
			for(let Variable of Search.Variables)Variables.push(Variable);
			Search=Search.Parent;
		}
		return Variables;
	}
	GetRawVariable(Name){
		for(let Variable of this.Variables)if(Variable.Name===Name)return Variable;
	}
	IsVariable(Name){
		return !!this.GetRawVariable(Name);	
	}
	VariablePrototype(Name,Value){
		return {
			Name:Name,
			Value:Value,
		};
	}
	GetGlobalRawVariable(Name){
		let Variable = this.GetRawVariable(Name);
		if(!Variable&&this.Parent)
			Variable=this.Parent.GetGlobalRawVariable(Name);
		return Variable;
	}
	GetVariable(Name){
		if(this.IsVariable(Name))return this.GetRawVariable(Name).Value;
		else if(this.Parent)return this.Parent.GetVariable(Name);
		return null;
	}
	SetVariable(Name,Value){
		if(this.IsVariable(Name)){
			let Variable=this.GetRawVariable(Name);
			Variable.Value=Value;
		}else if(this.Parent)this.Parent.SetVariable(Name,Value);
		else this.NewVariable(Name,Value);
	}
	NewVariable(Name,Value,Extra={}){
		let Variable=this.VariablePrototype(Name,Value);
		for(let Name in Extra)Variable[Name]=Extra[Name];
		if(this.IsVariable(Name))this.DeleteVariable(Name,true);
		this.Variables.push(Variable);
	}
	DeleteVariable(Name,Local=false){
		if(this.IsVariable(Name))
			for(let Key in this.Variables){
				Key=+Key;
				let Variable=this.Variables[Key];
				if(Variable.Name===Name){
					this.Variables.splice(Key,1);
					break;
				}
			}
		else if(this.Parent&&!Local)this.Parent.DeleteVariable(Name);
	}
}

/*************************\
      Internal States
\*************************/

const AssignmentStates = {
	0:async(stk,s,a,b)=>await b,
	1:async(stk,s,a,b)=>await OperatorStates.add(stk,s,a,b),
	2:async(stk,s,a,b)=>await OperatorStates.sub(stk,s,a,b),
	3:async(stk,s,a,b)=>await OperatorStates.mul(stk,s,a,b),
	4:async(stk,s,a,b)=>await OperatorStates.div(stk,s,a,b),
	5:async(stk,s,a,b)=>await OperatorStates.mod(stk,s,a,b),
	6:async(stk,s,a,b)=>await OperatorStates.pow(stk,s,a,b),
}

/*************************\
          States
\*************************/

const InterpreterStates = {
	GetVariable:async function(State,Token){
		return State.GetVariable(Token.Read("Name"));
	},
	NewVariable:async function(State,Token){
		let Variables = Token.Read("Variables");
		for(let Variable of Variables){
			State.NewVariable(Variable.Name,await this.Parse(State,Variable.Value),{
				Constant:Variable.Constant
			});
		}
	},
	Assignment:async function(State,Token){
		let Name = Token.Read("Name"),
			Value = await this.Parse(State,Token.Read("Value")),
			Call = AssignmentStates[Token.Read("Type")];
		if(Name instanceof ASTBase){
			if(Name.Type==="GetVariable"){
				Name = Name.Read("Name");
				let Variable=State.GetGlobalRawVariable(Name);
				if(Variable){
					if(Variable.Constant===true)ErrorHandler.InterpreterError(State,"Cannot",[`modify the constant variable ${Name}`]);
					let Previous=Variable.Value;
					State.SetVariable(Name,await Call(this,State,Variable.Value,Value));
					return Variable.Value;
				}else{
					let Result=await Call(this,State,null,Value);
					State.SetVariable(Name,Result);
					return Result;
				}
			}else if(Name.Type==="GetIndex"){
				let Obj = await this.Parse(State,Name.Read("Object")),
					Index = await this.Parse(State,Name.Read("Index")),
					ObjIndex = Obj[Index];
				if (Obj instanceof Function&&!this.IsAllowed){
					ErrorHandler.InterpreterError(Name,"Cannot",["index functions"])
				}
				let Result = await Call(this,State,ObjIndex,Value);
				Obj[Index]=Result;
				return Result;
			}
		}else{
			ErrorHandler.InterpreterError(Token,"Unexpected",["assignment operator"]);
		}
	},
	Add:async function(State,Token){
		let V1 = await this.Parse(State,Token.Read("V1")),
			V2 = await this.Parse(State,Token.Read("V2"));
		return V1+V2
	},
	Sub:async function(State,Token){
		let V1 = await this.Parse(State,Token.Read("V1")),
			V2 = await this.Parse(State,Token.Read("V2"));
		return V1-V2
	},
	Mul:async function(State,Token){
		let V1 = await this.Parse(State,Token.Read("V1")),
			V2 = await this.Parse(State,Token.Read("V2"));
		return V1*V2
	},
	Div:async function(State,Token){
		let V1 = await this.Parse(State,Token.Read("V1")),
			V2 = await this.Parse(State,Token.Read("V2"));
		return V1/V2
	},
	Mod:async function(State,Token){
		let V1 = await this.Parse(State,Token.Read("V1")),
			V2 = await this.Parse(State,Token.Read("V2"));
		return V1%V2
	},
	Pow:async function(State,Token){
		let V1 = await this.Parse(State,Token.Read("V1")),
			V2 = await this.Parse(State,Token.Read("V2"));
		return V1**V2
	},
	Negative:async function(State,Token){
		let V1 = await this.Parse(State,Token.Read("V1"));
		return -V1
	},
	Not:async function(State,Token){
		let V1 = await this.Parse(State,Token.Read("V1"));
		return !V1
	},
	And:async function(State,Token){
		let V1 = await this.Parse(State,Token.Read("V1"));
		if(V1){
			let V2 = await this.Parse(State,Token.Read("V2"));
			return V1&&V2
		}else return V1;
	},
	Or:async function(State,Token){
		let V1 = await this.Parse(State,Token.Read("V1"));
		if(V1){
			let V2 = await this.Parse(State,Token.Read("V2"));
			return V1||V2;
		}else return V1;
	},
	Eq:async function(State,Token){
		let V1 = await this.Parse(State,Token.Read("V1")),
			V2 = await this.Parse(State,Token.Read("V2"));
		return V1==V2
	},
	Lt:async function(State,Token){
		let V1 = await this.Parse(State,Token.Read("V1")),
			V2 = await this.Parse(State,Token.Read("V2"));
		return V1<V2
	},
	Leq:async function(State,Token){
		let V1 = await this.Parse(State,Token.Read("V1")),
			V2 = await this.Parse(State,Token.Read("V2"));
		return V1<=V2
	},
	Gt:async function(State,Token){
		let V1 = await this.Parse(State,Token.Read("V1")),
			V2 = await this.Parse(State,Token.Read("V2"));
		return V1>V2
	},
	Geq:async function(State,Token){
		let V1 = await this.Parse(State,Token.Read("V1")),
			V2 = await this.Parse(State,Token.Read("V2"));
		return V1>=V2
	},
	Neq:async function(State,Token){
		let V1 = await this.Parse(State,Token.Read("V1")),
			V2 = await this.Parse(State,Token.Read("V2"));
		return V1!=V2
	},
	Call:async function(State,Token){
		let Call = await this.Parse(State,Token.Read("Call")),
			Arguments = await this.ParseArray(State,Token.Read("Arguments"));
		if(!(Call instanceof Function))ErrorHandler.InterpreterError(Token,"Attempt",["to call non-function"]);
		if (Call.__JLANG_CLOSURE){
			return await Call(this,State,...Arguments);
		}
		return await Call(...Arguments);
	},
	Array:async function(State,Token){
		let List = Token.Read("List"),
		    Result = [];
		for(let v of List){
			let d = await this.Parse(State,v,true);
			if(d instanceof this.UnpackStateClass)for(let x of d.List)Result.push(x);
			else Result.push(d);
		}
		return Result;
	},
	Object:async function(State,Token){
		let Obj = Token.Read("Object"),
		    Result = {};
		for(let V of Obj)
			if(V.Value===undefined)Result[V.Name]=State.GetVariable(V.Name);
			else Result[await this.Parse(State,V.Name)]=await this.Parse(State,V.Value);
		return Result;
	},
	Break:async function(State,Token){
		State.Write("Break",true);	
	},
	Continue:async function(State,Token){
		State.Write("Continue",true);	
	},
	GetIndex:async function(State,Token){
		let Obj = await this.Parse(State,Token.Read("Object")),
		    Index = await this.Parse(State,Token.Read("Index"));
		if(Obj==null||Obj==undefined||typeof Obj=="number"){
			ErrorHandler.InterpreterError(Token,"Cannot",[`index the non-object value "${Obj}" with "${Index}"`])
		}
		if (Obj instanceof Function&&!this.IsAllowed){
			ErrorHandler.InterpreterError(Token,"Cannot",["index functions"])
		}
		return Obj[Index]
	},
	Length:async function(State,Token){
		let V1 = await this.Parse(State,Token.Read("V1"));
		return V1.length;
	},
	Repeat:async function(State,Token){
		let Amount = await this.Parse(State,Token.Read("Amount"));
		if(!this.IsAllowed){
			ErrorHandler.InterpreterError(Token,"NotAllowed",["use the repeat statement"])
		}
		for(let i=1;i<=Amount;i++){
			let NewState = new EpoxyState(Token.Read("Body"),State,{IsLoop:true,InLoop:true});
			await this.ParseState(NewState);
			if(!NewState.Read("InLoop"))break;
		}
	},
	Command:async function(State,Token){
		let Command = Token.Read("Command"),
			Parameters = await this.ParseArray(State,Token.Read("Parameters"));
		return await this.Hooks.CommandSystem.RunCommand(this,State,this.Message,Command,Parameters);
	},
	GetUser:async function(State,Token){
		return await this.Message.Guild.GetUser(String(Token.Read("Id")));
	},
	GetChannel:async function(State,Token){
		return await this.Message.Guild.GetChannel(String(Token.Read("Id")));
	},
	IterationLoop:async function(State,Token){
		let Variables = Token.Read("Variables"),
		    Getters = Token.Read("Getters"),
		    Iterator = await this.Parse(State,Token.Read("Object")),
		    Body = Token.Read("Body");
		for(let k in Iterator){
			let v=Iterator[k],
			    NewState = new EpoxyState(Body,State,{InLoop:true,IsLoop:true}),
			    Gets=[k,v];
			for(let Key in Variables){
				let Variable = Variables[Key];
				NewState.NewVariable(Variable.Name,Gets[Getters[Key]]);
			}
			await this.ParseState(NewState);
			if(!NewState.Read("InLoop"))break;
		}
	},
	If:async function(State,Token){
		let Expression = await this.Parse(State,Token.Read("Expression")),
		    Conditions = Token.Read("Conditions"),
		    Body = Token.Read("Body");
		if(Expression){
			let NewState = new EpoxyState(Body,State);
			await this.ParseState(NewState);
		}else{
			for(let Condition of Conditions){
				if(Condition.Type === "ElseIf"){
					let Exp = await this.Parse(State,Condition.Read("Expression")),
					    Bd = Condition.Read("Body");
					if(Exp){
						let NewState = new EpoxyState(Bd,State);
						await this.ParseState(NewState);
						break;
					}
				}else if(Condition.Type === "Else"){
					let Bd = Condition.Read("Body");
					let NewState = new EpoxyState(Bd,State);
					await this.ParseState(NewState);
					break;
				}
			}
		}
	},
	Portable:async function(State,Token){
		let Body = Token.Read("Body");
		return new PortableCode(State,Body);
	},
	ExecutePortable:async function(State,Token){
		let Portable = await this.Parse(State,Token.Read("Portable"));
		if(!(Portable instanceof PortableCode))throw Error(`Invalid ${Portable} after execportable statement`);
		return await Portable.Fire(this,State);
	},
}

class PortableCode {
	constructor(State,Body){
		let GlobalVariables = State.GetGlobalVariables();
		this.Fire = async function (IStack,S) {
			if (IStack instanceof InterpreterStack&&S instanceof EpoxyState){
				let B=new EpoxyState(Body,S);
				for(let Variable of GlobalVariables)B.TransferVariable(Variable);
				await IStack.ParseState(B);
				return B.Results;
			}
		}
	}
	toString(){
		return "[class PortableCode]";
	}
}

/*************************\
        Interpreter
\*************************/

const Interpreter = {
	New:function(ASTStack,Environment={}){
		return new InterpreterStack(ASTStack,Environment);
	},
	GetType:function(Value){
		let Type=typeof Value;
		if(Value instanceof Array)return"array";
		if(Value===null||Value===undefined)return"null";
		return Type;
	}
}

/*************************\
     Interpreter Stack
\*************************/

class UnpackState {
	constructor(List){
		this.List=List;
	}
}

class InterpreterStack {
	constructor(ASTStack,Environment){
		this.AStack=ASTStack,
			this.Tokens=ASTStack.Result,
			this.MainState=new EpoxyState(this.Tokens),
			this.Environment=Environment,
			this.Ended=false,
			this.EndedMessage="",
			this.Results=[];
		for(let Name in DefaultEnvironment)
			if(!Object.prototype.hasOwnProperty.call(Environment,Name))
				Environment[Name]=DefaultEnvironment[Name];
		for(let Name in Environment)this.MainState.NewVariable(Name,Environment[Name]);
		this.States = {};
		for(let Name in InterpreterStates)this.States[Name]=InterpreterStates[Name].bind(this);
		this.UnpackStateClass = UnpackState;
	}
	Result(...A){
		this.Results.push.apply(this.Results,A);
	}
	UnpackState(...Arguments){
		return new UnpackState(...Arguments);
	}
	async Parse(State,Token,Unpack=false){
		this.HandleEnded();
		if(!(Token instanceof ASTBase))return Token===undefined?null:Token;
		let Result = undefined;
		for(let Name in this.States){
			let Call = this.States[Name];
			if(Token.Type===Name){Result=await Call(State,Token);break}
			else if(Token.Type==="Unpack"){
				if(Unpack===true){
					let List=await this.Parse(State,Token.Read("List"),true);
					Result=new UnpackState(List);
					break;
				}else ErrorHandler.InterpreterError(Token,"Unexpected",["unpacking operator"]);
			}
		}
		return Result===undefined?null:Result;
	}
	HandleEnded(){
		if(this.Ended)ErrorHandler.InterpreterError(this.MainState,"Halt",[this.EndedMessage]);	
	}
	Quit(Message){
		this.Ended=true,
			this.EndedMessage=Message;
	}
	async ParseState(State,Unpack=false,Proxy){
		let S1=State,
			S2=State;
		if(Proxy)S1=Proxy;
		this.HandleEnded();
		while(!S1.IsEnd()){
			let Result=await this.Parse(S2,S1.Token,Unpack);
			if(State==this.MainState&&Result!=undefined){
				this.Results.push(Result);
			}
			if(Result!=undefined){
				S2.Results.push(Result);
			}
			S1.Next();
			if(S2.Read("Break")===true){
				S2.Write("InLoop",false);
				break;
			}
			if(S2.Read("Continue")===true)break;
			this.HandleEnded();
		}
		S1.Close();
	}
	async ParseArray(State,List){
		let Result=[];
		for(let k in List){
			let v=List[k],r=undefined;
			if(typeof v==="object"&&!(v instanceof ASTBase))r=await this.ParseArray(State,v);
			else r=await this.Parse(State,v,true);
			if(r instanceof UnpackState)for(let x of r.List)Result.push(x);
			else Result.push(r);
		}
		return Result;
	}
}

/*************************\
       Main Function
\*************************/

async function Main(Code,Environment={},Hooks,Message){
	let Result = {Success:false};
	try {
		let TStack = Tokenizer.New(Code);
		await TStack.Parse();
		let AStack = AST.New(TStack);
		await AStack.Parse();
		let IStack = Interpreter.New(AStack,Environment);
		IStack.Hooks=Hooks;
		IStack.Message=Message;
		if (AllowList.includes(Message.Author.ID)){
			IStack.IsAllowed=true;
		}
		if(Message.Author.ID==OwnerId){
			IStack.IsOwner=true;
		}
		Result.TStack=TStack,Result.AStack=AStack,Result.IStack=IStack;
		await IStack.ParseState(IStack.MainState);
		Result.Success = true;
		Result.Results=IStack.Results;
	}catch(Error){
		Result.Success=false,
			Result.Error=Error;
	}
	return Result;
}


//{{ JLang Constant }}\\

function Closure(F){
	F.__JLANG_CLOSURE=true;
	F.toString=function(){
		return "[J Closure]";
	}
	return F;
}

class UserInfo {
	constructor(Name,Tag,Id){
		this.name=Name,this.tag=Tag,this.id=Id;
	}
	toString(){
		let info=[];
		for(let k in this){
			if(k=="toString")continue;
			info.push(`${k}:${this[k]}`);
		}
		return `[class UserInfo {${info.join(", ")}}]`;
	}
}

const JLang = {
	Hooks:{},
	AddHook:function(Name,Value){
		this.Hooks[Name]=Value;
	},
	AddHooks:function(Reference){
		for(let Name in Reference)this.AddHook(Name,Reference[Name]);
	},
	Run:async function(Message,Content){
		const Library = {
			error:Closure(function(Stack,State,T){
				return ErrorHandler.InterpreterError(State,"Blank",[T]);
			}),
			log:Closure(function(Stack,State,...A){
				Stack.Result(A.join(" "));
			}),
			warn:Closure(function(Stack,State,...A){
				Stack.Result("/!\\: "+A.join(" "));
			}),
			getMemberInfo:Closure(function(Stack,State,Id){
				let Member = Stack.Message.Guild.GetUser(Id);
				if(!Member)return {};
				return new UserInfo(Member.Name,Member.Tag,Id);
			}),
			wait:Closure(async function(Stack,State,time){
				if(!Stack.IsAllowed&&time>5){
					ErrorHandler.InterpreterError(State,"Blank",["You are not allowed to wait more than 5 seconds per function call"]);
				}
				return await new Promise(x=>setTimeout(x,time*1000));
			}),
			math:{
				sin:(x)=>Math.sin(x),
				cos:(x)=>Math.cos(x),
				tan:(x)=>Math.tan(x),
				asin:(x)=>Math.asin(x),
				acos:(x)=>Math.acos(x),
				atan:(x)=>Math.atan(x),
				atan2:(y,x)=>Math.atan2(y,x),
				floor:(x)=>Math.floor(x),
				ceil:(x)=>Math.ceil(x),
				round:(x)=>Math.round(x),
				sqrt:(x)=>Math.sqrt(x),
				pow:(x)=>Math.pow(x),
				log:(x)=>Math.log(x),
				abs:(x)=>Math.abs(x),
				log10:(x)=>Math.log10(x),
				logb:(x,b=10)=>Math.log10(x)/Math.log10(b),
				nround:(x,b=0)=>{let m=10**b;return Math.floor(x*m+0.5)/m},
				rad:(x)=>x*(Math.PI/180),
				deg:(x)=>x*(180/Math.PI),
				random:(mi,ma)=>Math.floor(Math.random()*(ma-mi+1)+mi),
				nroot:(x,b=2)=>x**(1/b),
				max:(...a)=>Math.max(...a),
				min:(...a)=>Math.min(...a),
				clamp:(x,a,b)=>Math.max(a,Math.min(x,b)),
				pi:Math.PI,
				e:Math.E,
			},
		};
		if(AllowList.includes(Message.Author.ID)){
			Library.Message=Message,
			Library.Author=Message.Author,
			Library.Channel=Message.Channel;
			Library.Guild=Message.Channel.Guild;
		}
		if(Message.Author.ID==OwnerId){
			Library.Hooks=this.Hooks;
		}
		Library.env=Library;
		return await Main(Content,Library,this.Hooks,Message);
	},
};

//{{ JLang Export }}\\

for(let Name in JLang){
	let V = JLang[Name];
	if(typeof V=="function")V=V.bind(JLang);
	exports[Name]=V;
}

//X9BTRD6T4FQ6